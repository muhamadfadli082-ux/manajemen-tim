/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Player, Schedule, Assessment, Management, SyncSettings, AppSettings, UserRole } from './types';
import { 
  DEFAULT_PASSWORDS, 
  INITIAL_PLAYERS, 
  INITIAL_SCHEDULES, 
  INITIAL_ASSESSMENTS, 
  INITIAL_MANAGEMENT, 
  INITIAL_SYNC, 
  INITIAL_SETTINGS 
} from './utils/dummyData';
import LoginScreen from './components/LoginScreen';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import DashboardTab from './components/DashboardTab';
import DataManajemenTab from './components/DataManajemenTab';
import DataPemainTab from './components/DataPemainTab';
import JadwalTab from './components/JadwalTab';
import PenilaianTab from './components/PenilaianTab';
import SinkronTab from './components/SinkronTab';
import EksporImporTab from './components/EksporImporTab';
import PengaturanTab from './components/PengaturanTab';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  // Authentication states
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentRole, setCurrentRole] = useState<UserRole>('admin');
  const [allowedChildName, setAllowedChildName] = useState('');

  // Domain states
  const [players, setPlayers] = useState<Player[]>(INITIAL_PLAYERS);
  const [schedules, setSchedules] = useState<Schedule[]>(INITIAL_SCHEDULES);
  const [assessments, setAssessments] = useState<Assessment[]>(INITIAL_ASSESSMENTS);
  const [management, setManagement] = useState<Management>(INITIAL_MANAGEMENT);
  const [syncSettings, setSyncSettings] = useState<SyncSettings>(INITIAL_SYNC);
  const [appSettings, setAppSettings] = useState<AppSettings>(INITIAL_SETTINGS);
  
  // Passwords state (can be changed in settings)
  const [customPasswords, setCustomPasswords] = useState(DEFAULT_PASSWORDS);

  // Layout states
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(true);

  // Responsiveness: auto collapse sidebar on small devices
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1024) {
        setIsSidebarOpen(false);
      } else {
        setIsSidebarOpen(true);
      }
    };
    handleResize(); // Run once initially
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Sync to localStorage for true data persistence between sessions!
  useEffect(() => {
    const cachedPlayers = localStorage.getItem('alfaraby_players');
    const cachedSchedules = localStorage.getItem('alfaraby_schedules');
    const cachedAssessments = localStorage.getItem('alfaraby_assessments');
    const cachedManagement = localStorage.getItem('alfaraby_management');
    const cachedSync = localStorage.getItem('alfaraby_sync');
    const cachedSettings = localStorage.getItem('alfaraby_settings');
    const cachedPasswords = localStorage.getItem('alfaraby_passwords');

    if (cachedPlayers) setPlayers(JSON.parse(cachedPlayers));
    if (cachedSchedules) setSchedules(JSON.parse(cachedSchedules));
    if (cachedAssessments) setAssessments(JSON.parse(cachedAssessments));
    if (cachedManagement) setManagement(JSON.parse(cachedManagement));
    if (cachedSync) setSyncSettings(JSON.parse(cachedSync));
    if (cachedSettings) setAppSettings(JSON.parse(cachedSettings));
    if (cachedPasswords) setCustomPasswords(JSON.parse(cachedPasswords));
  }, []);

  const saveToLocalStorage = (key: string, data: any) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  // Auth Handler
  const handleLoginSuccess = (role: UserRole, childName: string) => {
    setCurrentRole(role);
    setAllowedChildName(childName);
    setIsLoggedIn(true);
    
    // Set default tab based on role privileges
    if (role === 'admin') setActiveTab('dashboard');
    else if (role === 'user') setActiveTab('dataPemain');
    else setActiveTab('dashboard'); // Wali murid
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setAllowedChildName('');
  };

  // Player Operations
  const handleAddPlayer = (newPlr: Omit<Player, 'id'> & { id?: string }) => {
    const updated = [
      ...players,
      {
        ...newPlr,
        id: newPlr.id || 'P' + (players.length + 1).toString().padStart(2, '0')
      }
    ] as Player[];
    setPlayers(updated);
    saveToLocalStorage('alfaraby_players', updated);
  };

  const handleEditPlayer = (editedPlr: Player) => {
    const updated = players.map(p => p.id === editedPlr.id ? editedPlr : p);
    setPlayers(updated);
    saveToLocalStorage('alfaraby_players', updated);
  };

  const handleDeletePlayer = (id: string) => {
    const updated = players.filter(p => p.id !== id);
    setPlayers(updated);
    saveToLocalStorage('alfaraby_players', updated);
  };

  const handleImportPlayers = (imported: Player[]) => {
    // Saring duplikasi nama atau ID untuk penggabungan aman
    const rawList = [...players];
    imported.forEach(iPlr => {
      const idx = rawList.findIndex(e => e.id === iPlr.id || e.name.toLowerCase() === iPlr.name.toLowerCase());
      if (idx !== -1) {
        rawList[idx] = { ...rawList[idx], ...iPlr }; // Gabungkan / update
      } else {
        rawList.push(iPlr);
      }
    });
    setPlayers(rawList);
    saveToLocalStorage('alfaraby_players', rawList);
  };

  // Schedule Operations
  const handleAddSchedule = (newSched: Omit<Schedule, 'id'>) => {
    const updated = [
      ...schedules,
      {
        ...newSched,
        id: 'S' + (schedules.length + 1).toString().padStart(2, '0')
      }
    ] as Schedule[];
    setSchedules(updated);
    saveToLocalStorage('alfaraby_schedules', updated);
  };

  const handleUpdateScore = (id: string, myScore: number, opponentScore: number) => {
    const updated = schedules.map(s => s.id === id ? { ...s, myScore, opponentScore, completed: true } : s);
    setSchedules(updated);
    saveToLocalStorage('alfaraby_schedules', updated);
  };

  // Assessment Operations
  const handleAddAssessment = (newAss: Omit<Assessment, 'id' | 'date'>) => {
    const updated = [
      ...assessments,
      {
        ...newAss,
        id: 'A' + (assessments.length + 1).toString().padStart(2, '0'),
        date: new Date().toISOString().slice(0, 10)
      }
    ] as Assessment[];
    setAssessments(updated);
    saveToLocalStorage('alfaraby_assessments', updated);
  };

  const handleImportAssessments = (imported: Assessment[]) => {
    const rawList = [...assessments];
    imported.forEach(iAss => {
      const idx = rawList.findIndex(e => e.id === iAss.id || (e.playerId === iAss.playerId && e.date === iAss.date));
      if (idx !== -1) {
        rawList[idx] = iAss;
      } else {
        rawList.push(iAss);
      }
    });
    setAssessments(rawList);
    saveToLocalStorage('alfaraby_assessments', rawList);
  };

  // Management updating
  const handleUpdateManagement = (data: Management) => {
    setManagement(data);
    saveToLocalStorage('alfaraby_management', data);
  };

  // Sync settings
  const handleUpdateSyncSettings = (data: Partial<SyncSettings>) => {
    const updated = { ...syncSettings, ...data };
    setSyncSettings(updated);
    saveToLocalStorage('alfaraby_sync', updated);
  };

  const handleTriggerSync = () => {
    const updated = {
      ...syncSettings,
      lastSynced: new Date().toISOString().replace('T', ' ').slice(0, 16)
    };
    setSyncSettings(updated);
    saveToLocalStorage('alfaraby_sync', updated);
  };

  // Security/Passwords change
  const handleUpdatePasswords = (passwords: { admin: string; user: string; wali: string }) => {
    setCustomPasswords(passwords);
    saveToLocalStorage('alfaraby_passwords', passwords);
  };

  // Styles preferences
  const handleUpdateAppSettings = (data: Partial<AppSettings>) => {
    const updated = { ...appSettings, ...data };
    setAppSettings(updated);
    saveToLocalStorage('alfaraby_settings', updated);
  };

  // Render Background Style berdasarkan AppSettings
  const getBackgroundClass = () => {
    if (!isDarkMode) return 'bg-[#f4f6f9] text-slate-900 border-gray-200';
    
    switch (appSettings.dashboardBg) {
      case 'sunset-pitch':
        return 'bg-[#0f172a] text-gray-100 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-950/20 via-slate-900 to-black';
      case 'neon-grid':
        return 'bg-[#030712] text-gray-100 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem]';
      case 'dark-grass':
        return 'bg-slate-950 text-gray-100 bg-[radial-gradient(ellipse_at_bottom_left,_var(--tw-gradient-stops))] from-emerald-950/20 via-slate-950 to-black';
      case 'cyber-field':
      default:
        return 'bg-[#030712] text-gray-100';
    }
  };

  // RENDERING COMPONENT ACCORDING TO USER NAVIGATION SELECTION (With security checks!)
  const renderActiveTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <DashboardTab
            players={players}
            schedules={schedules}
            management={management}
            onNavigateTab={(target) => setActiveTab(target)}
            isDarkMode={isDarkMode}
          />
        );
      case 'dataManajemen':
        return (
          <DataManajemenTab
            management={management}
            onUpdateManagement={handleUpdateManagement}
            playerCount={players.length}
          />
        );
      case 'dataPemain':
        return (
          <DataPemainTab
            players={players}
            role={currentRole}
            allowedChildName={allowedChildName}
            onAddPlayer={handleAddPlayer}
            onEditPlayer={handleEditPlayer}
            onDeletePlayer={handleDeletePlayer}
          />
        );
      case 'jadwal':
        return (
          <JadwalTab
            schedules={schedules}
            role={currentRole}
            onAddSchedule={handleAddSchedule}
            onUpdateScore={handleUpdateScore}
          />
        );
      case 'penilaian':
        return (
          <PenilaianTab
            players={players}
            assessments={assessments}
            role={currentRole}
            allowedChildName={allowedChildName}
            management={management}
            isAssessmentOpenToParents={appSettings.openAssessmentToParents}
            onAddAssessment={handleAddAssessment}
          />
        );
      case 'eksporImpor':
        return (
          <EksporImporTab
            players={players}
            assessments={assessments}
            role={currentRole}
            onImportPlayers={handleImportPlayers}
            onImportAssessments={handleImportAssessments}
          />
        );
      case 'sinkron':
        return (
          <SinkronTab
            syncSettings={syncSettings}
            role={currentRole}
            onUpdateSyncSettings={handleUpdateSyncSettings}
            onTriggerSync={handleTriggerSync}
          />
        );
      case 'pengaturan':
        return (
          <PengaturanTab
            management={management}
            appSettings={appSettings}
            customPasswords={customPasswords}
            onUpdateManagement={handleUpdateManagement}
            onUpdateAppSettings={handleUpdateAppSettings}
            onUpdatePasswords={handleUpdatePasswords}
            role={currentRole}
          />
        );
      default:
        return <div className="text-gray-400 font-mono">Ruang Panel tidak ditemukan.</div>;
    }
  };

  // JIKA BELUM LOGIN, TAMPILKAN LAYAR UTAMA TACTICAL LOGIN
  if (!isLoggedIn) {
    return (
      <LoginScreen
        onLoginSuccess={handleLoginSuccess}
        customPasswords={customPasswords}
        players={players}
      />
    );
  }

  return (
    <div className={`min-h-screen text-sans transition-colors duration-300 ${getBackgroundClass()}`}>
      
      {/* BACKGROUND GRAPHIC (Soccer Pitch overlays for futuristic high-tech theme) */}
      {isDarkMode && appSettings.dashboardBg === 'cyber-field' && (
        <div className="fixed inset-0 pointer-events-none opacity-5 z-0">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] height-[700px] border-4 border-dashed border-teal-500 rounded-full flex items-center justify-center">
            <div className="w-[350px] h-[350px] border-4 border-teal-500/80 rounded-full"></div>
          </div>
          <div className="absolute inset-0 border-y-4 border-teal-500/40 top-1/2 -translate-y-1/2"></div>
          <div className="absolute left-1/2 top-0 bottom-0 border-l-4 border-teal-500/40 -translate-x-1/2"></div>
        </div>
      )}

      {/* CORE PORTAL LAYOUT */}
      <div className="flex relative min-h-screen z-10 select-none">
        
        {/* Floating Sidebar Navigation */}
        <Sidebar
          activeTab={activeTab}
          onTabChange={(id) => setActiveTab(id)}
          isOpen={isSidebarOpen}
          onToggle={() => setIsSidebarOpen(!isSidebarOpen)}
          role={currentRole}
          childName={allowedChildName}
          onLogout={handleLogout}
          teamName={management.teamName}
        />

        {/* Dynamic Content View Area */}
        <div className={`flex-1 flex flex-col transition-all duration-300 ${
          isSidebarOpen ? 'pl-64' : 'pl-16'
        }`}>
          
          {/* Top Utilities Header */}
          <Header
            isSidebarOpen={isSidebarOpen}
            onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
            activeTab={activeTab}
            onTabChange={(id) => setActiveTab(id)}
            role={currentRole}
            isDarkMode={isDarkMode}
            onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
            teamName={management.teamName}
          />

          {/* Core Dashboard View Center */}
          <main className="p-6 md:p-8 flex-1 max-w-7xl w-full mx-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, scale: 0.99, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.99, y: -10 }}
                transition={{ duration: 0.15 }}
                className={`${!isDarkMode ? 'bg-white border border-slate-100 p-6 md:p-8 rounded-3xl shadow-sm' : ''}`}
              >
                {renderActiveTabContent()}
              </motion.div>
            </AnimatePresence>
          </main>

          {/* Small Footer credits */}
          <footer className="text-center py-6 text-gray-500 text-[10px] font-mono border-t border-slate-900/40 select-none no-print">
            © {new Date().getFullYear()} {management.teamName} (SD ISLAM AL FARABY FC) • Jl Mayor Damar no 44. All Rights Reserved.
          </footer>
        </div>
      </div>
    </div>
  );
}
