/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Shield, Users, UserCheck, Eye, EyeOff, HelpCircle, Lock, KeyRound } from 'lucide-react';
import { motion } from 'motion/react';
import { DEFAULT_PASSWORDS } from '../utils/dummyData';

interface LoginScreenProps {
  onLoginSuccess: (role: 'admin' | 'user' | 'wali', childName: string) => void;
  customPasswords?: { admin: string; user: string; wali: string };
  players: Array<{ name: string }>;
}

export default function LoginScreen({ onLoginSuccess, customPasswords, players }: LoginScreenProps) {
  const [role, setRole] = useState<'admin' | 'user' | 'wali'>('admin');
  const [password, setPassword] = useState('');
  const [selectedChild, setSelectedChild] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showForgotModal, setShowForgotModal] = useState(false);

  const activePasswords = customPasswords || DEFAULT_PASSWORDS;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    let correctPass = '';
    if (role === 'admin') correctPass = activePasswords.admin;
    else if (role === 'user') correctPass = activePasswords.user;
    else correctPass = activePasswords.wali;

    if (password === correctPass) {
      if (role === 'wali' && !selectedChild) {
        setErrorMsg('Silakan pilih nama putra/putri Anda terlebih dahulu.');
        return;
      }
      onLoginSuccess(role, role === 'wali' ? selectedChild : '');
    } else {
      setErrorMsg('Kata sandi salah. Silakan coba lagi atau gunakan fitur Lupa Sandi.');
    }
  };

  return (
    <div className="relative min-h-screen bg-[#030712] text-gray-100 flex flex-col justify-center items-center px-4 overflow-hidden">
      {/* Background sepakbola futuristik */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border-2 border-teal-500/30 rounded-full flex items-center justify-center">
          <div className="w-[300px] h-[300px] border-2 border-teal-500/20 rounded-full flex items-center justify-center">
            <div className="w-[100px] h-[100px] border-2 border-teal-500/10 rounded-full"></div>
          </div>
        </div>
        <div className="absolute inset-0 border-y border-teal-500/10 top-1/2 -translate-y-1/2"></div>
        <div className="absolute left-1/2 top-0 bottom-0 border-l border-teal-500/20 -translate-x-1/2"></div>
        <div className="absolute top-12 left-12 w-32 h-20 border-r border-b border-teal-500/20"></div>
        <div className="absolute bottom-12 right-12 w-32 h-20 border-l border-t border-teal-500/20"></div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md bg-slate-900/80 backdrop-blur-md rounded-2xl border border-teal-500/30 p-8 shadow-2xl relative z-10"
      >
        <div className="text-center mb-8">
          <div className="inline-flex p-3 rounded-full bg-teal-500/10 border border-teal-500/30 text-teal-400 mb-3 animate-pulse">
            <span className="text-3xl">⚽</span>
          </div>
          <h1 className="text-2xl font-bold font-sans tracking-tight text-white mb-1">
            AL FARABY FC
          </h1>
          <p className="text-xs font-mono text-teal-400 uppercase tracking-widest">
            Manajemen Team Sepakbola
          </p>
          <p className="text-xs text-gray-400 mt-1">SD ISLAM AL FARABY</p>
        </div>

        {/* Pemilihan Role */}
        <div className="grid grid-cols-3 gap-2 p-1 bg-slate-950 rounded-xl border border-slate-800 mb-6">
          <button
            type="button"
            onClick={() => { setRole('admin'); setErrorMsg(''); }}
            className={`flex flex-col items-center gap-1.5 py-3 px-2 rounded-lg text-xs font-medium transition-all ${
              role === 'admin'
                ? 'bg-teal-500 text-slate-950 font-bold shadow-lg'
                : 'text-gray-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Shield className="w-4 h-4" />
            Admin
          </button>
          <button
            type="button"
            onClick={() => { setRole('user'); setErrorMsg(''); }}
            className={`flex flex-col items-center gap-1.5 py-3 px-2 rounded-lg text-xs font-medium transition-all ${
              role === 'user'
                ? 'bg-teal-500 text-slate-950 font-bold shadow-lg'
                : 'text-gray-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            Coach (User)
          </button>
          <button
            type="button"
            onClick={() => { setRole('wali'); setErrorMsg(''); }}
            className={`flex flex-col items-center gap-1.5 py-3 px-2 rounded-lg text-xs font-medium transition-all ${
              role === 'wali'
                ? 'bg-teal-500 text-slate-950 font-bold shadow-lg'
                : 'text-gray-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Users className="w-4 h-4" />
            Wali Murid
          </button>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          {/* Opsi nama murid jika wali murid */}
          {role === 'wali' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-1"
            >
              <label className="text-xs font-semibold text-teal-400 block">Pilih Nama Siswa (Pemain):</label>
              <select
                value={selectedChild}
                onChange={(e) => setSelectedChild(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2.5 px-3 text-sm text-gray-200 focus:outline-none focus:ring-1 focus:ring-teal-500 focus:border-teal-500"
              >
                <option value="">-- Pilih Putra/Putri Anda --</option>
                {players.map((plr, i) => (
                  <option key={i} value={plr.name}>{plr.name}</option>
                ))}
              </select>
            </motion.div>
          )}

          <div className="space-y-1">
            <label className="text-xs font-semibold text-teal-400 block">Sandi Akses:</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500 pointer-events-none">
                <Lock className="w-4 h-4" />
              </span>
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Masukkan kata sandi..."
                required
                className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2.5 pl-10 pr-10 text-sm text-gray-200 focus:outline-none focus:ring-1 focus:ring-teal-500 focus:border-teal-500"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-white"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {errorMsg && (
            <div className="text-xs text-red-400 bg-red-950/40 border border-red-900/50 p-2.5 rounded-lg text-center font-medium">
              {errorMsg}
            </div>
          )}

          <button
            type="submit"
            className="w-full py-2.5 bg-teal-500 text-slate-950 text-sm font-bold rounded-lg hover:bg-teal-400 transition-all font-sans tracking-wide uppercase mt-6"
          >
            Masuk ke Aplikasi
          </button>
        </form>

        <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-800 text-xs text-gray-500">
          <button
            onClick={() => setShowForgotModal(true)}
            className="hover:text-teal-400 transition-all flex items-center gap-1 font-medium"
          >
            <HelpCircle className="w-3.5 h-3.5" /> Lupa kata sandi?
          </button>
          <span>v1.2 Secure Web</span>
        </div>
      </motion.div>

      {/* Modal Lupa Sandi */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-sm bg-slate-900 border border-teal-500/40 rounded-2xl p-6 shadow-2xl"
          >
            <div className="flex items-center gap-2 mb-4 text-teal-400">
              <KeyRound className="w-5 h-5 animate-bounce" />
              <h3 className="text-sm font-bold uppercase tracking-wider font-mono">Bantuan Sandi Default</h3>
            </div>
            <p className="text-xs text-gray-400 leading-relaxed mb-4">
              Untuk kebutuhan review di AI Studio, berikut adalah akun default untuk masing-masing login role pengguna:
            </p>
            <div className="space-y-2 bg-slate-950 p-3 rounded-xl border border-slate-800 text-[11px] font-mono">
              <div className="flex justify-between border-b border-slate-900 pb-1.5">
                <span className="text-teal-400">Admin:</span>
                <span className="text-white font-bold">{activePasswords.admin}</span>
              </div>
              <div className="flex justify-between border-b border-slate-900 pb-1.5">
                <span className="text-teal-400">Coach (User):</span>
                <span className="text-white font-bold">{activePasswords.user}</span>
              </div>
              <div className="flex justify-between pb-0.5">
                <span className="text-teal-400">Wali Murid:</span>
                <span className="text-white font-bold">{activePasswords.wali}</span>
              </div>
            </div>
            <p className="text-[10px] text-gray-500 mt-3 italic">
              * Sandi ini dapat diubah kapan saja di menu "Pengaturan" setelah masuk menggunakan akses Admin.
            </p>
            <button
              onClick={() => setShowForgotModal(false)}
              className="w-full mt-5 py-2 bg-teal-500/10 hover:bg-teal-500/20 text-teal-400 font-bold text-xs rounded-lg transition-all border border-teal-500/30"
            >
              Tutup & Kembali
            </button>
          </motion.div>
        </div>
      )}
    </div>
  );
}
