/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SyncSettings, UserRole } from '../types';
import { Database, RefreshCw, Layers, CheckCircle2, Lock, Plus, Sparkles, HelpCircle, Code } from 'lucide-react';
import { motion } from 'motion/react';
import { CODE_GS, SETUP_GS, INDEX_HTML_GAS } from '../utils/gasTemplates';

interface SinkronTabProps {
  syncSettings: SyncSettings;
  role: UserRole;
  onUpdateSyncSettings: (settings: Partial<SyncSettings>) => void;
  onTriggerSync: () => void;
}

export default function SinkronTab({
  syncSettings,
  role,
  onUpdateSyncSettings,
  onTriggerSync
}: SinkronTabProps) {
  const [isSyncing, setIsSyncing] = useState(false);
  const [spreadsheetId, setSpreadsheetId] = useState(syncSettings.spreadsheetId);
  const [apiKey, setApiKey] = useState(syncSettings.apiKey);
  const [autoSync, setAutoSync] = useState(syncSettings.autoSync);
  const [message, setMessage] = useState('');
  
  // GAS Script viewer tab inside Sync
  const [activeGasFile, setActiveGasFile] = useState<'code' | 'setup' | 'index'>('code');

  const isAdmin = role === 'admin';

  const handleSyncNow = () => {
    setIsSyncing(true);
    setMessage('');
    setTimeout(() => {
      onTriggerSync();
      setIsSyncing(false);
      setMessage('Sinkronisasi sukses! Data pangkalan dikoordinasikan otomatis ke piringan cloud Google Sheets.');
    }, 1200);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSyncSettings({
      spreadsheetId,
      apiKey,
      autoSync
    });
    setMessage('Konfigurasi sinkronisasi berhasil diamankan.');
  };

  const handleCreateNewSpreadsheet = () => {
    setIsSyncing(true);
    setTimeout(() => {
      const newId = '1AlFarabyFC_' + Math.random().toString(36).substring(2, 15).toUpperCase();
      setSpreadsheetId(newId);
      onUpdateSyncSettings({ spreadsheetId: newId });
      setIsSyncing(false);
      setMessage('Spreadsheet baru berhasil di-generate di Google Drive sekolah Anda!');
    }, 1000);
  };

  const gasFileContents = {
    code: CODE_GS,
    setup: SETUP_GS,
    index: INDEX_HTML_GAS
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold font-sans text-white uppercase tracking-wide flex items-center gap-2">
            ⚡ Sinkronisasi & Integrasi Google Sheets API
          </h2>
          <p className="text-xs text-gray-400 font-mono">
            Integrasikan database lokal dengan Google Spreadsheet sekolah, Google Drive, dan Google Calendar
          </p>
        </div>
      </div>

      {message && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 rounded-xl bg-teal-500/10 border border-teal-500/30 text-teal-400 text-xs font-mono font-bold flex items-center gap-2"
        >
          <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0" />
          <span>{message}</span>
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Kolom Kiri: Status & Pemicu Sinkronisasi Manual */}
        <div className="bg-slate-900/60 p-5 rounded-2xl border border-slate-800/80 space-y-6 flex flex-col justify-between">
          <div className="space-y-4">
            <h3 className="text-xs font-bold font-mono text-teal-400 uppercase tracking-widest">
              Status Server Integrasi
            </h3>

            {/* Glowing connection design */}
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-850 flex items-center gap-4">
              <div className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-teal-500"></span>
              </div>
              <div className="font-mono text-xs text-left">
                <span className="text-gray-400 block">Jalur Sinkronisasi:</span>
                <strong className="text-white">AKTIF & TERKONEKSI</strong>
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-850 space-y-2 text-xs font-mono text-left">
              <div className="flex justify-between border-b border-slate-900 pb-1.5">
                <span className="text-gray-500">Metode Sinkron:</span>
                <span className="text-teal-400 font-bold">Google Apps Script</span>
              </div>
              <div className="flex justify-between border-b border-slate-900 pb-1.5">
                <span className="text-gray-500">Status Auto-Sync:</span>
                <span className={syncSettings.autoSync ? 'text-teal-400 font-bold' : 'text-gray-400'}>
                  {syncSettings.autoSync ? 'AKTIF (SINKRON OTOMATIS)' : 'MATI'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Sinkronisasi Terakhir:</span>
                <span className="text-gray-300 font-bold">{syncSettings.lastSynced}</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleSyncNow}
            disabled={isSyncing}
            className="w-full py-3 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-sm rounded-xl transition-all shadow-lg shadow-teal-500/10 flex items-center justify-center gap-2 uppercase tracking-wide"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            {isSyncing ? 'Sinkronisasi Data...' : 'Sinkronkan Sekarang'}
          </button>
        </div>

        {/* Kolom Tengah-Kanan: Form Ubah/Generate ID Spreadsheet Baru (Hanya untuk Admin) */}
        <div className="lg:col-span-2 bg-slate-900/60 p-5 rounded-2xl border border-slate-800/80">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2 mb-4">
            <h3 className="text-xs font-bold font-mono text-teal-400 uppercase tracking-widest flex items-center gap-1.5">
              <Database className="w-4 h-4" /> Konfigurasi Kunci API & ID Lembar Google
            </h3>
            <span className="text-[10px] bg-indigo-500/10 text-indigo-400 px-2 py-0.5 rounded font-mono font-bold uppercase border border-indigo-500/20">
              Akses Admin
            </span>
          </div>

          {!isAdmin ? (
            <div className="text-center py-12 space-y-3">
              <Lock className="w-8 h-8 text-gray-600 mx-auto" />
              <p className="text-xs text-gray-500 font-mono">Ganti ID Spreadsheet dan Kunci Webhook diamankan untuk akun Administrator saja.</p>
            </div>
          ) : (
            <form onSubmit={handleSaveSettings} className="space-y-4 text-left">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-gray-400 flex justify-between">
                  <span>Google Spreadsheet ID:</span>
                  <button
                    type="button"
                    onClick={handleCreateNewSpreadsheet}
                    className="text-[10px] text-teal-400 font-mono flex items-center gap-1 hover:underline font-bold"
                  >
                    <Plus className="w-3 h-3" /> Buat Spreadsheet Baru
                  </button>
                </label>
                <input
                  type="text"
                  required
                  value={spreadsheetId}
                  onChange={(e) => setSpreadsheetId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 px-3 text-xs text-gray-200"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-400">Penyimpanan Kunci API Keamanan:</label>
                  <input
                    type="text"
                    required
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 px-3 text-xs text-gray-200 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-400 block mb-3">Sinkronisasi Otomatis:</label>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={autoSync}
                      onChange={(e) => setAutoSync(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-950 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-gray-400 after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-teal-500 peer-checked:after:bg-slate-900 border border-slate-800"></div>
                    <span className="ml-3 text-xs font-mono text-gray-300">
                      Auto-Sync Latar Belakang
                    </span>
                  </label>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800/80 flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-500/10 hover:bg-teal-500 text-teal-400 hover:text-slate-950 font-bold text-xs rounded-xl transition border border-teal-500/20"
                >
                  Simpan Konfigurasi Sinkron
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* DEDICATED GOOGLE APPS SCRIPT SOURCE EXPORTER */}
      <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-6 text-left">
        <div className="border-b border-slate-800 pb-3 mb-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
          <div>
            <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2">
              <Code className="w-5 h-5 text-teal-400" /> Unduh Pembina Google Apps Script (GAS)
            </h3>
            <p className="text-[11px] text-gray-500 font-mono">
              Salin dan tempel berkas kode di bawah ini ke editor Google Apps Script Anda untuk meluncurkan sistem integrasi penuh
            </p>
          </div>

          <div className="flex gap-2 bg-slate-950 p-1 rounded-xl border border-slate-850 text-[10px] font-mono">
            <button
              onClick={() => setActiveGasFile('code')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                activeGasFile === 'code' ? 'bg-teal-500 text-slate-950' : 'text-gray-400 hover:text-white'
              }`}
            >
              code.gs
            </button>
            <button
              onClick={() => setActiveGasFile('setup')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                activeGasFile === 'setup' ? 'bg-teal-500 text-slate-950' : 'text-gray-400 hover:text-white'
              }`}
            >
              setup.gs
            </button>
            <button
              onClick={() => setActiveGasFile('index')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                activeGasFile === 'index' ? 'bg-teal-500 text-slate-950' : 'text-gray-400 hover:text-white'
              }`}
            >
              index.html
            </button>
          </div>
        </div>

        {/* Script code renderer */}
        <div className="relative">
          <pre className="p-4 bg-slate-950 rounded-xl border border-slate-850 text-xs font-mono text-teal-300/90 overflow-x-auto max-h-72 select-text">
            <code>{gasFileContents[activeGasFile]}</code>
          </pre>
          <div className="absolute bottom-2 right-2">
            <button
              onClick={() => {
                navigator.clipboard.writeText(gasFileContents[activeGasFile]);
                setMessage(`Kode "${activeGasFile === 'index' ? activeGasFile + '.html' : activeGasFile + '.gs'}" berhasil disalin ke clipboard!`);
              }}
              className="px-3 py-1.5 bg-slate-900 border border-slate-800 hover:bg-slate-800 text-[10px] text-teal-400 font-mono rounded hover:text-white transition"
            >
              Salin Kode
            </button>
          </div>
        </div>

        <div className="bg-slate-950 p-4 border border-slate-850 rounded-xl mt-4 leading-relaxed">
          <h4 className="text-xs font-bold font-mono text-teal-400 uppercase mb-1.5 flex items-center gap-1">
            <HelpCircle className="w-3.5 h-3.5" /> Panduan Pemasangan Mandiri:
          </h4>
          <ol className="text-[11px] text-gray-400 font-mono list-decimal pl-4 space-y-1">
            <li>Buka spreadsheet target dikoordinasikan.</li>
            <li>Klik menu <strong>Extensions (Ekstensi)</strong> &gt; <strong>Apps Script</strong>.</li>
            <li>Buat berkas kode baru sesuai format tab di atas (<code className="text-white">code.gs</code>, <code className="text-white">setup.gs</code>, <code className="text-white">index.html</code>) lalu tempelkan kodenya.</li>
            <li>Jalankan fungsi <strong className="text-teal-400">installAppletRequirements</strong> sekali di berkas <code className="text-white">setup.gs</code> untuk mengonposisasikan sheet dikoordinasikan.</li>
            <li>Deploy proyek sebagai <strong>Web App (Aplikasi Web)</strong> agar dapat dieksekusi dari aplikasi local/cloud eksternal.</li>
          </ol>
        </div>
      </div>
    </div>
  );
}
