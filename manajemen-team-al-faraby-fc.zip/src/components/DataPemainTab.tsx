/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Player, UserRole } from '../types';
import { Search, Plus, Trash2, Edit2, Info, ArrowUpDown, Filter, Save, X, Eye, Image as ImageIcon, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

interface DataPemainTabProps {
  players: Player[];
  role: UserRole;
  allowedChildName?: string;
  onAddPlayer: (player: Omit<Player, 'id'> & { id?: string }) => void;
  onEditPlayer: (player: Player) => void;
  onDeletePlayer: (id: string) => void;
}

// Koleksi Gambar Avatar Sepakbola Mock untuk Pencarian Drive/Lokal
const MOCK_DRIVE_PHOTOS = [
  { name: 'Siswa Penyerang - Ahmad', url: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=200&q=80', tag: 'Penyerang' },
  { name: 'Siswa Bek - Bagas', url: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&q=80', tag: 'Bek' },
  { name: 'Siswa Gelandang - Anam', url: 'https://images.unsplash.com/photo-1489980508314-941910ded1f4?w=200&q=80', tag: 'Gelandang' },
  { name: 'Siswa Kiper - Dani', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80', tag: 'Kiper' },
  { name: 'Atribut Sepakbola Merah', url: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=200&q=80', tag: 'Atribut' },
  { name: 'Atribut Sepakbola Hijau', url: 'https://images.unsplash.com/photo-1518063319789-7217e6706b04?w=200&q=80', tag: 'Atribut' },
  { name: 'Akademi Al Faraby Muda', url: 'https://images.unsplash.com/photo-1517649763962-0c623066013b?w=200&q=80', tag: 'Squad' },
  { name: 'Pemain Latihan Solo', url: 'https://images.unsplash.com/photo-1526232761682-d26e03ac148e?w=200&q=80', tag: 'Fisik' }
];

export default function DataPemainTab({
  players,
  role,
  allowedChildName,
  onAddPlayer,
  onEditPlayer,
  onDeletePlayer
}: DataPemainTabProps) {
  // Filter & Sorting states
  const [searchTerm, setSearchTerm] = useState('');
  const [positionFilter, setPositionFilter] = useState<string>('Semua');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Modal / Form states
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);

  // Form Fields
  const [editingPlayerId, setEditingPlayerId] = useState<string | null>(null);
  const [nameInput, setNameInput] = useState('');
  const [positionInput, setPositionInput] = useState<'Kiper' | 'Bek' | 'Gelandang' | 'Penyerang'>('Penyerang');
  const [birthdateInput, setBirthdateInput] = useState('');
  const [photoInput, setPhotoInput] = useState('👤');
  const [classInput, setClassInput] = useState('');
  const [weightInput, setWeightInput] = useState('');
  const [heightInput, setHeightInput] = useState('');
  const [phoneInput, setPhoneInput] = useState('');

  // Drive/Local Photo Assistant State
  const [driveKeyword, setDriveKeyword] = useState('');
  const [foundPhotos, setFoundPhotos] = useState<Array<{ name: string; url: string }>>([]);
  const [isDriveSearching, setIsDriveSearching] = useState(false);

  const isAdmin = role === 'admin';

  // Saring pemain berdasarkan hak akses login Wali Murid
  let filteredPlayers = [...players];
  if (role === 'wali' && allowedChildName) {
    filteredPlayers = players.filter(p => p.name.toLowerCase() === allowedChildName.toLowerCase());
  }

  // Saring berdasarkan input pencarian
  if (searchTerm) {
    filteredPlayers = filteredPlayers.filter(p =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.position.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }

  // Saring berdasarkan Posisi
  if (positionFilter !== 'Semua') {
    filteredPlayers = filteredPlayers.filter(p => p.position === positionFilter);
  }

  // Urutan abjad A-Z atau Z-A
  filteredPlayers.sort((a, b) => {
    const comp = a.name.localeCompare(b.name);
    return sortOrder === 'asc' ? comp : -comp;
  });

  // Reset form baru
  const resetForm = () => {
    setEditingPlayerId(null);
    setNameInput('');
    setPositionInput('Penyerang');
    setBirthdateInput('2014-01-01');
    setPhotoInput('👤');
    setClassInput('Siswa Kelas 5-A');
    setWeightInput('40 kg');
    setHeightInput('145 cm');
    setPhoneInput('081234567890');
    setDriveKeyword('');
    setFoundPhotos([]);
  };

  const handleOpenAdd = () => {
    resetForm();
    setShowAddModal(true);
  };

  const handleOpenEdit = (player: Player) => {
    setEditingPlayerId(player.id);
    setNameInput(player.name);
    setPositionInput(player.position);
    setBirthdateInput(player.birthdate || '2014-01-01');
    setPhotoInput(player.photo || '👤');
    setClassInput(player.className || 'Siswa Kelas 5-A');
    setWeightInput(player.weight || '40 kg');
    setHeightInput(player.height || '145 cm');
    setPhoneInput(player.phone || '081234567890');
    setShowAddModal(true);
  };

  // Simpan data (Mampu simpan hanya dengan menginput 2 data nama dan posisi!)
  const handleSaveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) return;

    if (editingPlayerId) {
      // Edit mode
      onEditPlayer({
        id: editingPlayerId,
        name: nameInput,
        position: positionInput,
        birthdate: birthdateInput || '2014-01-01',
        photo: photoInput || '👤',
        className: classInput || 'Siswa Kelas 5',
        weight: weightInput || '40 kg',
        height: heightInput || '145 cm',
        phone: phoneInput || '081230000000',
        statusActive: true
      });
    } else {
      // Tambah baru
      onAddPlayer({
        name: nameInput,
        position: positionInput,
        birthdate: birthdateInput || '2014-01-01',
        photo: photoInput || '👤',
        className: classInput || 'Siswa Kelas 5',
        weight: weightInput || '40 kg',
        height: heightInput || '145 cm',
        phone: phoneInput || '081230000000',
        statusActive: true
      });
    }

    setShowAddModal(false);
    resetForm();
  };

  // Fungsi pencarian foto di Google Drive / Local disk
  const handleDriveSearch = () => {
    setIsDriveSearching(true);
    setTimeout(() => {
      const keyword = driveKeyword.toLowerCase();
      const results = MOCK_DRIVE_PHOTOS.filter(photo =>
        photo.name.toLowerCase().includes(keyword) ||
        photo.tag.toLowerCase().includes(keyword)
      );
      setFoundPhotos(results.length > 0 ? results : MOCK_DRIVE_PHOTOS.slice(0, 4));
      setIsDriveSearching(false);
    }, 600);
  };

  return (
    <div className="space-y-6">
      {/* Search and Filters Header */}
      <div className="bg-slate-900/40 p-4 border border-slate-800 rounded-2xl flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="relative w-full md:w-72">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400 pointer-events-none">
            <Search className="w-4 h-4" />
          </span>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Cari nama pemain..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 pl-9 pr-4 text-xs text-gray-200 focus:outline-none focus:ring-1 focus:ring-teal-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto justify-end">
          {/* Filter Posisi */}
          <div className="flex items-center gap-1.5 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs text-gray-300">
            <Filter className="w-3.5 h-3.5 text-teal-400" />
            <select
              value={positionFilter}
              onChange={(e) => setPositionFilter(e.target.value)}
              className="bg-transparent focus:outline-none cursor-pointer"
            >
              <option value="Semua" className="bg-slate-950">Semua Posisi</option>
              <option value="Penyerang" className="bg-slate-950">Penyerang</option>
              <option value="Gelandang" className="bg-slate-950">Gelandang</option>
              <option value="Bek" className="bg-slate-950">Bek</option>
              <option value="Kiper" className="bg-slate-950">Kiper</option>
            </select>
          </div>

          {/* Pengurutan A-Z */}
          <button
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            className="flex items-center gap-1.5 bg-slate-950 hover:bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800 text-xs text-gray-300 font-medium transition"
          >
            <ArrowUpDown className="w-3.5 h-3.5 text-teal-400" />
            Nama: {sortOrder === 'asc' ? 'A-Z' : 'Z-A'}
          </button>

          {/* Tombol Add Player - Hanya untuk Admin */}
          {isAdmin && (
            <button
              onClick={handleOpenAdd}
              className="flex items-center gap-1.5 px-4 py-2 bg-teal-500 text-slate-950 font-bold text-xs rounded-xl hover:bg-teal-400 transition shadow-lg shadow-teal-500/10"
            >
              <Plus className="w-3.5 h-3.5" /> Tambah Pemain
            </button>
          )}
        </div>
      </div>

      {/* Skuad Card Grid Layout (Not traditional tables) */}
      {filteredPlayers.length === 0 ? (
        <div className="text-center py-16 bg-slate-950/20 border border-dashed border-slate-800 rounded-2xl">
          <span className="text-4xl text-gray-600 block mb-3">👥</span>
          <p className="text-sm text-gray-400 font-mono">Belum ada data skuat pemain yang cocok ditemukan.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {filteredPlayers.map((player) => (
            <motion.div
              key={player.id}
              whileHover={{ y: -5 }}
              onClick={() => { setSelectedPlayer(player); setShowDetailModal(true); }}
              className="bg-slate-900/60 rounded-2xl border border-slate-850 hover:border-teal-500/30 p-5 flex flex-col items-center text-center cursor-pointer relative shadow-xl group transition-all"
            >
              {/* Posisi Badge */}
              <span className={`absolute top-4 right-4 text-[9px] font-mono font-bold px-2.5 py-0.5 rounded-full ${
                player.position === 'Penyerang' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/25' :
                player.position === 'Gelandang' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/25' :
                player.position === 'Bek' ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/25' :
                'bg-cyan-500/10 text-cyan-400 border border-cyan-500/25'
              }`}>
                {player.position}
              </span>

              {/* Avatar / Foto Profil */}
              <div className="w-16 h-16 rounded-full bg-slate-950 flex items-center justify-center border border-slate-800 select-none overflow-hidden mb-3.5 shadow-inner">
                {player.photo && player.photo.startsWith('http') ? (
                  <img src={player.photo} alt={player.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <span className="text-3xl font-bold">{player.photo || '👤'}</span>
                )}
              </div>

              {/* Info Sederhana */}
              <h3 className="font-bold text-white text-sm tracking-wide group-hover:text-teal-400 transition-colors uppercase">
                {player.name}
              </h3>
              <p className="text-[11px] font-mono text-gray-500 mt-1">
                {player.className || 'Siswa Al Faraby'}
              </p>

              {/* Atribut Fisik Cepat */}
              <div className="flex gap-2.5 mt-4 text-[10px] font-mono text-gray-400 bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-900 leading-none">
                <span>📏 {player.height || '-'}</span>
                <span className="border-l border-slate-800"></span>
                <span>⚖️ {player.weight || '-'}</span>
              </div>

              {/* Aksi Tambahan untuk Admin */}
              {isAdmin && (
                <div className="w-full flex justify-end gap-1.5 mt-5 pt-3 border-t border-slate-800/40 opacity-80 group-hover:opacity-100 transition-opacity" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={() => handleOpenEdit(player)}
                    className="p-1 px-2.5 rounded bg-slate-950 hover:bg-teal-500 hover:text-slate-950 border border-slate-850 hover:border-teal-400 text-teal-400 transition text-[10px] font-mono flex items-center gap-1"
                  >
                    <Edit2 className="w-3 h-3" /> Edit
                  </button>
                  <button
                    onClick={() => onDeletePlayer(player.id)}
                    className="p-1 px-2.5 rounded bg-slate-950 hover:bg-rose-600 hover:text-white border border-slate-850 hover:border-rose-400 text-rose-400 transition text-[10px] font-mono flex items-center gap-1"
                  >
                    <Trash2 className="w-3 h-3" /> Hapus
                  </button>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      )}

      {/* MODAL INPUT PEMAIN BARU / EDIT (Bisa save Cukup input 2 data saja!) */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-2xl bg-slate-900 border border-teal-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col md:flex-row"
          >
            {/* Sisi Kiri: Foto / Avatar dan Search Google Drive */}
            <div className="w-full md:w-5/12 bg-slate-950 p-6 flex flex-col justify-between border-b md:border-b-0 md:border-r border-slate-800">
              <div className="space-y-4">
                <div className="text-center">
                  <div className="text-xs uppercase font-mono tracking-wider text-teal-400 font-bold mb-3">Foto Profil Siswa</div>
                  <div className="w-24 h-24 rounded-full bg-slate-900 border border-teal-500/30 flex items-center justify-center mx-auto shadow-inner overflow-hidden">
                    {photoInput.startsWith('http') ? (
                      <img src={photoInput} alt="Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <span className="text-5xl">{photoInput}</span>
                    )}
                  </div>
                  <div className="mt-3 flex justify-center gap-2">
                    <button
                      type="button"
                      onClick={() => setPhotoInput('👤')}
                      className="px-2 py-1 text-[10px] bg-slate-900 border border-slate-800 text-gray-400 rounded hover:text-white"
                    >
                      Reset 👤
                    </button>
                  </div>
                </div>

                {/* Pencari Gambar di Drive / Local */}
                <div className="space-y-2 pt-4 border-t border-slate-900">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-gray-400 font-bold block flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-teal-400" /> Cari Foto (Drive/Lokal)
                  </span>
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      placeholder="Input nama/posisi..."
                      value={driveKeyword}
                      onChange={(e) => setDriveKeyword(e.target.value)}
                      className="flex-1 bg-slate-900 border border-slate-800 rounded px-2 py-1 text-xs text-gray-200 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleDriveSearch}
                      className="px-2.5 py-1 bg-teal-500 text-slate-950 font-bold text-xs rounded hover:bg-teal-400 transition"
                    >
                      {isDriveSearching ? 'Cari...' : 'Cari'}
                    </button>
                  </div>

                  {/* Hasil Mock Google Drive */}
                  <div className="grid grid-cols-4 gap-1.5 max-h-24 overflow-y-auto pt-2">
                    {(foundPhotos.length > 0 ? foundPhotos : MOCK_DRIVE_PHOTOS).map((item, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setPhotoInput(item.url)}
                        className="relative group w-11 h-11 rounded border border-slate-800 bg-slate-900 overflow-hidden hover:border-teal-500"
                        title={item.name}
                      >
                        <img src={item.url} alt="mock" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        <span className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-[8px] text-white font-bold leading-none">
                          PILIH
                        </span>
                      </button>
                    ))}
                  </div>
                  <span className="text-[9px] text-gray-500 italic block">
                    * Pencarian otomatis mencocokkan database file drive yang diotorisasi oleh SD Al Faraby.
                  </span>
                </div>
              </div>

              <div className="text-[10px] text-gray-500 font-mono mt-4 text-center">
                SD ISLAM AL FARABY FC
              </div>
            </div>

            {/* Sisi Kanan: Form Data */}
            <form onSubmit={handleSaveSubmit} className="flex-1 p-6 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                  <h3 className="text-sm font-bold font-mono uppercase text-white tracking-wide">
                    {editingPlayerId ? 'Edit Biodata Pemain' : 'Tambah Pemain Baru'}
                  </h3>
                  <div className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded font-mono font-bold uppercase">
                    CUKUP INPUT 2 DATA UNTUK SIMPAN
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Wajib 1: Nama */}
                  <div className="space-y-1 md:col-span-2">
                    <label className="text-xs font-semibold text-teal-400 flex items-center gap-1">
                      Nama Lengkap Siswa * <span className="text-[10px] text-gray-400 font-normal">(Wajib)</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Masukkan nama lengkap siswa..."
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200 focus:outline-none focus:ring-1 focus:ring-teal-500"
                    />
                  </div>

                  {/* Wajib 2: Posisi */}
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-teal-400 flex items-center gap-1">
                      Posisi Pemain * <span className="text-[10px] text-gray-400 font-normal">(Wajib)</span>
                    </label>
                    <select
                      value={positionInput}
                      onChange={(e: any) => setPositionInput(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200 focus:outline-none"
                    >
                      <option value="Penyerang">Penyerang (Forward)</option>
                      <option value="Gelandang">Gelandang (Midfielder)</option>
                      <option value="Bek">Bek (Defender)</option>
                      <option value="Kiper">Kiper (Goalkeeper)</option>
                    </select>
                  </div>

                  {/* Opsional: Tgl Lahir */}
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-gray-400">Tanggal Lahir (Opsional)</label>
                    <input
                      type="date"
                      value={birthdateInput}
                      onChange={(e) => setBirthdateInput(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200 focus:outline-none"
                    />
                  </div>

                  {/* Opsional: Kelas */}
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-gray-400">Kelas Siswa (Opsional)</label>
                    <input
                      type="text"
                      placeholder="Contoh: Siswa Kelas 5A"
                      value={classInput}
                      onChange={(e) => setClassInput(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200"
                    />
                  </div>

                  {/* Opsional: Berat */}
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-gray-400">Berat Badan (Opsional)</label>
                    <input
                      type="text"
                      placeholder="e.g. 40 kg"
                      value={weightInput}
                      onChange={(e) => setWeightInput(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200"
                    />
                  </div>

                  {/* Opsional: Tinggi */}
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-gray-400">Tinggi Badan (Opsional)</label>
                    <input
                      type="text"
                      placeholder="e.g. 145 cm"
                      value={heightInput}
                      onChange={(e) => setHeightInput(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200"
                    />
                  </div>

                  {/* Opsional: Telepon */}
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-gray-400">No. HP Wali (Opsional)</label>
                    <input
                      type="text"
                      placeholder="e.g. 0812345..."
                      value={phoneInput}
                      onChange={(e) => setPhoneInput(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200"
                    />
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-4 border-t border-slate-800 flex justify-end gap-3.5">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-850 hover:bg-slate-800 text-gray-400 text-xs font-semibold rounded-lg transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-6 py-2 bg-teal-500 text-slate-950 text-xs font-extrabold rounded-lg hover:bg-teal-400 transition"
                >
                  <Save className="w-3.5 h-3.5" /> Simpan Data
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* MODAL BIODATA / DETAILS (Tampil Saat Nama Siswa Diklik) */}
      {showDetailModal && selectedPlayer && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-md bg-gradient-to-b from-slate-900 to-slate-950 border border-teal-500/40 rounded-2xl overflow-hidden shadow-2xl relative"
          >
            {/* Decors */}
            <div className="absolute top-0 right-0 w-28 h-28 bg-teal-500/10 rounded-full blur-2xl"></div>

            {/* Header / Banner */}
            <div className="relative h-24 bg-gradient-to-r from-teal-950 to-slate-900 border-b border-teal-500/20 flex items-center justify-center pt-2">
              <span className="text-xs font-mono text-teal-400 font-bold uppercase tracking-widest bg-slate-950/80 px-3 py-1 rounded-full border border-teal-500/30">
                PROFIL BIODATA PEMAIN
              </span>
              <button
                onClick={() => setShowDetailModal(false)}
                className="absolute top-4 right-4 p-1.5 bg-slate-950/60 rounded-full border border-slate-800 text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content Card layout */}
            <div className="p-6 text-center space-y-6 relative -mt-10">
              {/* Profile Image */}
              <div className="inline-flex w-20 h-20 rounded-full bg-slate-950 border-2 border-teal-500 shadow-xl overflow-hidden items-center justify-center">
                {selectedPlayer.photo && selectedPlayer.photo.startsWith('http') ? (
                  <img src={selectedPlayer.photo} alt={selectedPlayer.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <span className="text-4xl">{selectedPlayer.photo || '👤'}</span>
                )}
              </div>

              {/* Biodata Title */}
              <div>
                <h3 className="text-xl font-extrabold text-white uppercase font-sans tracking-wide">
                  {selectedPlayer.name}
                </h3>
                <span className="px-3 py-1 rounded-full bg-teal-500/10 border border-teal-500/20 text-teal-400 text-[10px] font-mono uppercase font-bold mt-2 inline-block">
                  🛡️ {selectedPlayer.position}
                </span>
              </div>

              {/* Grid Atribut Lengkap */}
              <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800/80 text-left space-y-3 font-mono text-xs">
                <div className="flex justify-between border-b border-slate-900 pb-2">
                  <span className="text-gray-500">ID Skuad:</span>
                  <span className="text-gray-300 font-semibold">{selectedPlayer.id}</span>
                </div>
                <div className="flex justify-between border-b border-slate-900 pb-2">
                  <span className="text-gray-500">Tanggal Lahir:</span>
                  <span className="text-gray-300 font-semibold">{selectedPlayer.birthdate || '-'}</span>
                </div>
                <div className="flex justify-between border-b border-slate-900 pb-2">
                  <span className="text-gray-500">Kelas Siswa:</span>
                  <span className="text-gray-300 font-semibold">{selectedPlayer.className || 'Kelas 5'}</span>
                </div>
                <div className="flex justify-between border-b border-slate-900 pb-2">
                  <span className="text-gray-500">Tinggi Badan:</span>
                  <span className="text-teal-400 font-bold">{selectedPlayer.height || '-'}</span>
                </div>
                <div className="flex justify-between border-b border-slate-900 pb-2">
                  <span className="text-gray-500">Berat Badan:</span>
                  <span className="text-teal-400 font-bold">{selectedPlayer.weight || '-'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Status Skuad:</span>
                  <span className="text-emerald-400 font-bold">✓ Aktif Al Faraby FC</span>
                </div>
              </div>

              <button
                onClick={() => setShowDetailModal(false)}
                className="w-full py-2 bg-slate-900 hover:bg-slate-850 text-gray-300 font-bold text-xs rounded-lg transition-all border border-slate-800"
              >
                Tutup Jendela
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
