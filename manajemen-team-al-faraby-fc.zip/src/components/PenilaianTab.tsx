/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Player, Assessment, UserRole, Management } from '../types';
import { Award, Plus, Sparkles, AlertCircle, FileText, User, Calendar, Star, Send, X, Printer } from 'lucide-react';
import { motion } from 'motion/react';

interface PenilaianTabProps {
  players: Player[];
  assessments: Assessment[];
  role: UserRole;
  allowedChildName?: string;
  management: Management;
  isAssessmentOpenToParents: boolean;
  onAddAssessment: (assessment: Omit<Assessment, 'id' | 'date'>) => void;
}

export default function PenilaianTab({
  players,
  assessments,
  role,
  allowedChildName,
  management,
  isAssessmentOpenToParents,
  onAddAssessment
}: PenilaianTabProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [activeReportPlayer, setActiveReportPlayer] = useState<Assessment | null>(null);

  // Form states
  const [selectedPlayerId, setSelectedPlayerId] = useState('');
  const [knowledge, setKnowledge] = useState<number>(80);
  const [passing, setPassing] = useState<number>(80);
  const [dribbling, setDribbling] = useState<number>(80);
  const [control, setControl] = useState<number>(80);
  const [shooting, setShooting] = useState<number>(80);
  const [individualSkill, setIndividualSkill] = useState<number>(80);
  const [vision, setVision] = useState<number>(80);
  const [response, setResponse] = useState<number>(80);
  const [jump, setJump] = useState<number>(80);
  const [teamwork, setTeamwork] = useState<number>(80);
  const [matchMental, setMatchMental] = useState<number>(80);
  const [spirit, setSpirit] = useState<number>(80);
  const [endurance, setEndurance] = useState<number>(80);
  const [notes, setNotes] = useState('');

  const isAdmin = role === 'admin';
  const isUser = role === 'user';
  const isWali = role === 'wali';

  // Wali murid can read-only, but ONLY if assessment is opened
  const canViewAsWali = isWali && isAssessmentOpenToParents;

  // Filter assessment records
  let filteredAssessments = [...assessments];
  if (isWali) {
    if (!isAssessmentOpenToParents) {
      filteredAssessments = [];
    } else if (allowedChildName) {
      filteredAssessments = assessments.filter(a => a.playerName.toLowerCase() === allowedChildName.toLowerCase());
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPlayerId) return;

    const matchedPlayer = players.find(p => p.id === selectedPlayerId);
    if (!matchedPlayer) return;

    onAddAssessment({
      playerId: selectedPlayerId,
      playerName: matchedPlayer.name,
      knowledge,
      passing,
      dribbling,
      control,
      shooting,
      individualSkill,
      vision,
      response,
      jump,
      teamwork,
      matchMental,
      spirit,
      endurance,
      notes: notes || 'Pemain menunjukkan dedikasi yang baik dalam latihan.',
      evaluator: role === 'admin' ? 'Administrator Klub' : management.headCoach
    });

    setShowAddForm(false);
    // Reset Form
    setSelectedPlayerId('');
    setNotes('');
  };

  // Kalkulasi total rerata skor
  const getAverageScore = (a: Assessment) => {
    const scores = [
      a.knowledge, a.passing, a.dribbling, a.control,
      a.shooting, a.individualSkill, a.vision, a.response,
      a.jump, a.teamwork, a.matchMental, a.spirit, a.endurance
    ];
    const total = scores.reduce((sum, current) => sum + current, 0);
    return Math.round(total / scores.length);
  };

  const getPerformanceBadge = (avg: number) => {
    if (avg >= 85) return { text: 'A - ISTIMEWA', color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' };
    if (avg >= 75) return { text: 'B - BAIK', color: 'bg-teal-500/10 text-teal-300 border-teal-500/30' };
    if (avg >= 60) return { text: 'C - CUKUP', color: 'bg-amber-500/10 text-amber-300 border-amber-500/30' };
    return { text: 'D - PERLU MELATIH DIRI', color: 'bg-rose-500/10 text-rose-400 border-rose-500/30' };
  };

  // Fungsi pencetakan rapot
  const handlePrintRaport = () => {
    const printContent = document.getElementById('raport-print-box')?.innerHTML;
    if (!printContent) return;

    const winPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
    if (winPrint) {
      winPrint.document.write(`
        <html>
          <head>
            <title>RAPOR EVALUASI PEMAIN - AL FARABY FC</title>
            <style>
              body { font-family: 'Arial', sans-serif; color: #111; padding: 40px; line-height: 1.5; font-size: 14px; }
              .kop { text-align: center; border-bottom: 3px double #111; padding-bottom: 12px; margin-bottom: 25px; }
              .kop h1 { margin: 0; font-size: 22px; font-weight: bold; }
              .kop h2 { margin: 5px 0 0 0; font-size: 16px; font-weight: normal; }
              .kop p { margin: 4px 0 0 0; font-size: 11px; font-style: italic; color: #555; }
              .info-pemain { margin-bottom: 25px; display: flex; justify-content: space-between; }
              .info-pemain table { width: 45%; border-collapse: collapse; }
              .info-pemain td { padding: 4px 0; }
              .table-nilai { width: 100%; border-collapse: collapse; margin-bottom: 25px; }
              .table-nilai th, .table-nilai td { border: 1px solid #111; padding: 10px; text-align: left; }
              .table-nilai th { bg-color: #f2f2f2; font-weight: bold; }
              .table-nilai td.center { text-align: center; }
              .catatan { border: 1px solid #111; padding: 12px; margin-bottom: 35px; border-radius: 4px; }
              .catatan-title { font-weight: bold; margin-bottom: 6px; }
              .ttd-box { display: flex; justify-content: space-between; margin-top: 50px; text-align: center; }
              .ttd-col { width: 40%; }
              @media print {
                .no-print { display: none; }
              }
            </style>
          </head>
          <body onload="window.print();window.close()">
            ${printContent}
          </body>
        </html>
      `);
      winPrint.document.close();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold font-sans text-white uppercase tracking-wide flex items-center gap-2">
            🏆 Hasil Penilaian & Rapor Evaluasi Fisik
          </h2>
          <p className="text-xs text-gray-400 font-mono">
            Pemantauan kompetensi pengetahuan taktik, teknik individu, spirit tanding, dan evaluasi daya tahan
          </p>
        </div>

        {/* Akses Wali Murid Warning */}
        {isWali && !isAssessmentOpenToParents && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-500/10 text-rose-400 border border-rose-500/20 text-xs rounded-xl font-mono">
            <AlertCircle className="w-4 h-4" /> Akses Rapor Ditutup Sementara
          </div>
        )}

        {(isAdmin || isUser) && (
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center gap-1.5 px-4 py-2 bg-teal-500 text-slate-950 font-bold text-xs rounded-xl hover:bg-teal-400 transition shadow-lg shadow-teal-500/10"
          >
            <Plus className="w-3.5 h-3.5" /> Berikan Penilaian
          </button>
        )}
      </div>

      {/* TAMPILAN JIKA WALI MURID DAN AKSES DITUTUP */}
      {isWali && !isAssessmentOpenToParents && (
        <div className="text-center py-20 bg-slate-950/40 border border-slate-900 rounded-3xl space-y-4">
          <div className="text-5xl">🔒</div>
          <h3 className="text-lg font-bold text-white uppercase font-sans">PORTAL PENILAIAN DIKUNCI</h3>
          <p className="text-xs text-gray-400 font-mono max-w-md mx-auto">
            Mohon maaf, evaluasi rapor belum dibuka oleh Pelatih dan Kepala Sekolah. Silakan hubungi admin sekolah untuk meminta akses dibuka.
          </p>
          <p className="text-[11px] text-gray-500 font-mono">
            Email Sekolah: {management.email}
          </p>
        </div>
      )}

      {/* LIST NILAI DALAM BENTUK CARD (NOT TABLES) */}
      {filteredAssessments.length === 0 ? (
        ((isWali && isAssessmentOpenToParents) || !isWali) && (
          <div className="text-center py-16 bg-slate-950/20 border border-dashed border-slate-850 rounded-2xl">
            <Star className="w-12 h-12 text-gray-600 mx-auto mb-3 animate-pulse" />
            <p className="text-sm text-gray-400 font-mono">Belum ada catatan evaluasi performa pemain yang terekam.</p>
          </div>
        )
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredAssessments.map((item) => {
            const avg = getAverageScore(item);
            const badge = getPerformanceBadge(avg);
            return (
              <motion.div
                key={item.id}
                whileHover={{ scale: 1.005 }}
                className="bg-slate-900/60 rounded-2xl border border-slate-850 p-5 flex flex-col justify-between hover:border-teal-400/30 transition shadow-xl"
              >
                {/* Header Card Nilai */}
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl">🏅</span>
                    <div>
                      <h3 className="text-sm font-extrabold text-white uppercase font-sans">{item.playerName}</h3>
                      <p className="text-[10px] text-gray-500 font-mono">Uji Coba Tgl: {item.date}</p>
                    </div>
                  </div>
                  <span className={`px-2.5 py-1 text-[9px] font-mono font-bold rounded-full border ${badge.color}`}>
                    {badge.text}
                  </span>
                </div>

                {/* Score indicators */}
                <div className="grid grid-cols-3 gap-2 py-3 bg-slate-950/80 rounded-xl px-4 border border-slate-900 text-xs font-mono">
                  <div className="text-center border-r border-slate-900">
                    <span className="text-[10px] text-gray-500 block">TAKTIKAL</span>
                    <strong className="text-sm text-white">{item.knowledge}</strong>
                  </div>
                  <div className="text-center border-r border-slate-900">
                    <span className="text-[10px] text-gray-500 block">DRIBBLE</span>
                    <strong className="text-sm text-white">{item.dribbling}</strong>
                  </div>
                  <div className="text-center">
                    <span className="text-[10px] text-gray-500 block">RATA-RATA</span>
                    <strong className="text-sm text-teal-400 font-black">{avg}/100</strong>
                  </div>
                </div>

                {/* Deskripsi Evaluasi Tambahan */}
                <p className="text-[11px] text-gray-400 bg-slate-950 p-3 rounded-lg border border-slate-900 mt-3 italic line-clamp-2">
                  " {item.notes} "
                </p>

                {/* Footer and Report Card Opener */}
                <div className="mt-5 pt-3 border-t border-slate-800/80 flex justify-between items-center text-[10px] font-mono text-gray-500">
                  <span>Evaluator: {item.evaluator}</span>
                  <button
                    onClick={() => setActiveReportPlayer(item)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-500/10 hover:bg-teal-500 text-teal-400 hover:text-slate-950 transition rounded-lg border border-teal-500/20 text-xs font-sans font-bold"
                  >
                    <FileText className="w-3.5 h-3.5" /> Buka Rapot Evaluasi
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* FORM INPUT PENILAIAN BARU */}
      {showAddForm && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-xl bg-slate-900 border border-teal-500/40 rounded-2xl p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-teal-400" /> Lembar Penilaian Siswa
              </h3>
              <button
                onClick={() => setShowAddForm(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-left">
              {/* Pilih Pemain */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-teal-400">Pilih Pemain Skuad:</label>
                <select
                  required
                  value={selectedPlayerId}
                  onChange={(e) => setSelectedPlayerId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200"
                >
                  <option value="">-- Pilih Pemain --</option>
                  {players.map(p => (
                    <option key={p.id} value={p.id}>{p.name} - {p.position}</option>
                  ))}
                </select>
              </div>

              {/* Slider Penilaian */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-300 flex justify-between">
                    <span>Pengetahuan Takti & Sepakbola</span>
                    <strong className="text-teal-400 font-mono text-[11px]">{knowledge}</strong>
                  </label>
                  <input type="range" min="40" max="100" value={knowledge} onChange={(e) => setKnowledge(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-400" />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-300 flex justify-between">
                    <span>Teknik Passing (Menghantar)</span>
                    <strong className="text-teal-400 font-mono text-[11px]">{passing}</strong>
                  </label>
                  <input type="range" min="40" max="100" value={passing} onChange={(e) => setPassing(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-400" />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-300 flex justify-between">
                    <span>Teknik Dribbling (Menggiring)</span>
                    <strong className="text-teal-400 font-mono text-[11px]">{dribbling}</strong>
                  </label>
                  <input type="range" min="40" max="100" value={dribbling} onChange={(e) => setDribbling(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-400" />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-300 flex justify-between">
                    <span>Teknik Control Bola</span>
                    <strong className="text-teal-400 font-mono text-[11px]">{control}</strong>
                  </label>
                  <input type="range" min="40" max="100" value={control} onChange={(e) => setControl(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-400" />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-300 flex justify-between">
                    <span>Akurasi Shooting (Menembak)</span>
                    <strong className="text-teal-400 font-mono text-[11px]">{shooting}</strong>
                  </label>
                  <input type="range" min="40" max="100" value={shooting} onChange={(e) => setShooting(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-400" />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-300 flex justify-between">
                    <span>Keterampilan Individu</span>
                    <strong className="text-teal-400 font-mono text-[11px]">{individualSkill}</strong>
                  </label>
                  <input type="range" min="40" max="100" value={individualSkill} onChange={(e) => setIndividualSkill(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-400" />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-300 flex justify-between">
                    <span>Visi & Misi Bermain</span>
                    <strong className="text-teal-400 font-mono text-[11px]">{vision}</strong>
                  </label>
                  <input type="range" min="40" max="100" value={vision} onChange={(e) => setVision(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-400" />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-300 flex justify-between">
                    <span>Respon & Kecepatan Berpikir</span>
                    <strong className="text-teal-400 font-mono text-[11px]">{response}</strong>
                  </label>
                  <input type="range" min="40" max="100" value={response} onChange={(e) => setResponse(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-400" />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-300 flex justify-between">
                    <span>Jump & Duel Udara</span>
                    <strong className="text-teal-400 font-mono text-[11px]">{jump}</strong>
                  </label>
                  <input type="range" min="40" max="100" value={jump} onChange={(e) => setJump(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-400" />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-300 flex justify-between">
                    <span>Kerjasama Tim</span>
                    <strong className="text-teal-400 font-mono text-[11px]">{teamwork}</strong>
                  </label>
                  <input type="range" min="40" max="100" value={teamwork} onChange={(e) => setTeamwork(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-400" />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-300 flex justify-between">
                    <span>Mental Bertanding</span>
                    <strong className="text-teal-400 font-mono text-[11px]">{matchMental}</strong>
                  </label>
                  <input type="range" min="40" max="100" value={matchMental} onChange={(e) => setMatchMental(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-400" />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-300 flex justify-between">
                    <span>Semangat Bermain / Spirit</span>
                    <strong className="text-teal-400 font-mono text-[11px]">{spirit}</strong>
                  </label>
                  <input type="range" min="40" max="100" value={spirit} onChange={(e) => setSpirit(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-400" />
                </div>

                <div className="space-y-1 md:col-span-2">
                  <label className="text-xs font-semibold text-gray-300 flex justify-between">
                    <span>Daya Tahan Fisik (Endurance)</span>
                    <strong className="text-teal-400 font-mono text-[11px]">{endurance}</strong>
                  </label>
                  <input type="range" min="40" max="100" value={endurance} onChange={(e) => setEndurance(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-400" />
                </div>
              </div>

              {/* Catatan / Evaluasi */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-teal-400">Deskripsi & Catatan Tambahan (Catatan Evaluasi):</label>
                <textarea
                  required
                  placeholder="Masukkan ulasan deskripsi mengenai kekuatan, kelemahan, serta arahan masa depan pemain..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200 focus:outline-none"
                />
              </div>

              <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 bg-slate-850 hover:bg-slate-800 text-gray-400 text-xs rounded-lg transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-500 text-slate-950 font-bold text-xs rounded-lg hover:bg-teal-400 transition"
                >
                  Simpan Nilai Evaluasi
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* MODAL LAPORAN RAPOT DETIL & PRINT PDF */}
      {activeReportPlayer && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-2xl bg-white text-slate-900 rounded-2xl overflow-hidden shadow-2xl relative flex flex-col max-h-[92vh]"
          >
            {/* Header Dialog Kontrol - No Print */}
            <div className="bg-slate-900 text-white px-6 py-4 flex justify-between items-center no-print">
              <span className="text-xs font-mono font-bold tracking-wider uppercase text-teal-400">
                Raport Evaluasi Pemain - Digital Preview
              </span>
              <div className="flex gap-2">
                <button
                  onClick={handlePrintRaport}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-sans font-bold text-xs rounded-lg transition"
                >
                  <Printer className="w-4 h-4" /> Cetak Raport (PDF)
                </button>
                <button
                  onClick={() => setActiveReportPlayer(null)}
                  className="p-1 px-2.5 bg-slate-800 hover:bg-slate-700 text-gray-400 hover:text-white rounded-lg transition text-xs"
                >
                  Tutup
                </button>
              </div>
            </div>

            {/* BOX KERTAS RAPOT PRINTABLE */}
            <div id="raport-print-box" className="p-10 overflow-y-auto text-left flex-1 bg-white select-text">
              {/* Kop Surat Bagian Atas */}
              <div className="kop border-b-4 border-double border-slate-900 pb-4 text-center">
                <div style={{ fontSize: '12px', fontWeight: 'bold', letterSpacing: '1px', textTransform: 'uppercase', color: '#444' }}>
                  Pendidikan Jasmani & Bakat Olahraga
                </div>
                <h1 style={{ fontSize: '24px', fontWeight: 'bold', color: '#111', margin: '4px 0 2px 0' }}>
                  SD ISLAM AL FARABY
                </h1>
                <h2 style={{ fontSize: '14px', fontWeight: 'bold', color: '#333', margin: 0 }}>
                  AL FARABY INDONESIAN FOOTBALL ACADEMY
                </h2>
                <p style={{ fontSize: '10px', color: '#666', fontStyle: 'italic', margin: '4px 0 0 0' }}>
                  {management.address} • NPSN: {management.npsn} • sdialfaraby238@gmail.com
                </p>
              </div>

              {/* Judul Rapor */}
              <div className="text-center mb-6">
                <h3 style={{ fontSize: '16px', fontWeight: 'bold', letterSpacing: '0.5px', textTransform: 'uppercase', margin: 0 }}>
                  RAPOR EVALUASI ASPEK PEMAIN
                </h3>
                <span style={{ fontSize: '12px', color: '#666', fontStyle: 'italic' }}>
                  Periode Semester / Angkatan Kejuaraan
                </span>
              </div>

              {/* Biodata Atas */}
              <div className="info-pemain flex justify-between gap-8 mb-5 text-sm" style={{ borderBottom: '1px solid #ddd', paddingBottom: '12px' }}>
                <table style={{ width: '48%', borderCollapse: 'collapse' }}>
                  <tbody>
                    <tr>
                      <td style={{ color: '#555', width: '40%', padding: '3px 0' }}>Nama Murid</td>
                      <td style={{ fontWeight: 'bold', padding: '3px 0' }}>: {activeReportPlayer.playerName}</td>
                    </tr>
                    <tr>
                      <td style={{ color: '#555', padding: '3px 0' }}>ID Pemain</td>
                      <td style={{ fontWeight: 'bold', padding: '3px 0' }}>: {activeReportPlayer.playerId}</td>
                    </tr>
                  </tbody>
                </table>
                <table style={{ width: '48%', borderCollapse: 'collapse' }}>
                  <tbody>
                    <tr>
                      <td style={{ color: '#555', width: '40%', padding: '3px 0' }}>Uji Penilaian</td>
                      <td style={{ fontWeight: 'bold', padding: '3px 0' }}>: {activeReportPlayer.date}</td>
                    </tr>
                    <tr>
                      <td style={{ color: '#555', padding: '3px 0' }}>Kelompok Umur</td>
                      <td style={{ fontWeight: 'bold', padding: '3px 0' }}>: SD Islam Al Faraby FC</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Tabel Penilaian Berisi 2 Kolom (kategori penilaian & skor/nilai) */}
              <table className="table-nilai" style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #111', fontSize: '13px' }}>
                <thead>
                  <tr style={{ backgroundColor: '#f1f5f9' }}>
                    <th style={{ border: '1px solid #111', padding: '9px 12px', textAlign: 'left', fontWeight: 'bold' }}>KATEGORI PENILAIAN</th>
                    <th style={{ border: '1px solid #111', padding: '9px 12px', textAlign: 'center', fontWeight: 'bold', width: '130px' }}>SKOR / NILAI (0-100)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style={{ border: '1px solid #111', padding: '7px 12px' }}>Pengetahuan Taktikal & Aturan Sepakbola</td>
                    <td className="center" style={{ border: '1px solid #111', padding: '7px 12px', textAlign: 'center', fontWeight: 'bold' }}>{activeReportPlayer.knowledge}</td>
                  </tr>
                  <tr>
                    <td style={{ border: '1px solid #111', padding: '7px 12px' }}>Keterampilan Passing (Operan Dasar)</td>
                    <td className="center" style={{ border: '1px solid #111', padding: '7px 12px', textAlign: 'center', fontWeight: 'bold' }}>{activeReportPlayer.passing}</td>
                  </tr>
                  <tr>
                    <td style={{ border: '1px solid #111', padding: '7px 12px' }}>Keterampilan Dribbling (Menggiring Bola)</td>
                    <td className="center" style={{ border: '1px solid #111', padding: '7px 12px', textAlign: 'center', fontWeight: 'bold' }}>{activeReportPlayer.dribbling}</td>
                  </tr>
                  <tr>
                    <td style={{ border: '1px solid #111', padding: '7px 12px' }}>Kontrol Bola (First Touch)</td>
                    <td className="center" style={{ border: '1px solid #111', padding: '7px 12px', textAlign: 'center', fontWeight: 'bold' }}>{activeReportPlayer.control}</td>
                  </tr>
                  <tr>
                    <td style={{ border: '1px solid #111', padding: '7px 12px' }}>Akurasi Shooting (Tembakan Gol)</td>
                    <td className="center" style={{ border: '1px solid #111', padding: '7px 12px', textAlign: 'center', fontWeight: 'bold' }}>{activeReportPlayer.shooting}</td>
                  </tr>
                  <tr>
                    <td style={{ border: '1px solid #111', padding: '7px 12px' }}>Visi & Misi Bermain (Kerjasama Ruang)</td>
                    <td className="center" style={{ border: '1px solid #111', padding: '7px 12px', textAlign: 'center', fontWeight: 'bold' }}>{activeReportPlayer.vision}</td>
                  </tr>
                  <tr>
                    <td style={{ border: '1px solid #111', padding: '7px 12px' }}>Respon & Kecepatan Berpikir</td>
                    <td className="center" style={{ border: '1px solid #111', padding: '7px 12px', textAlign: 'center', fontWeight: 'bold' }}>{activeReportPlayer.response}</td>
                  </tr>
                  <tr>
                    <td style={{ border: '1px solid #111', padding: '7px 12px' }}>Jump & Duel Udara</td>
                    <td className="center" style={{ border: '1px solid #111', padding: '7px 12px', textAlign: 'center', fontWeight: 'bold' }}>{activeReportPlayer.jump}</td>
                  </tr>
                  <tr>
                    <td style={{ border: '1px solid #111', padding: '7px 12px' }}>Kerjasama Tim (Teamwork)</td>
                    <td className="center" style={{ border: '1px solid #111', padding: '7px 12px', textAlign: 'center', fontWeight: 'bold' }}>{activeReportPlayer.teamwork}</td>
                  </tr>
                  <tr>
                    <td style={{ border: '1px solid #111', padding: '7px 12px' }}>Mental Bertanding (Ketenangan di Lapangan)</td>
                    <td className="center" style={{ border: '1px solid #111', padding: '7px 12px', textAlign: 'center', fontWeight: 'bold' }}>{activeReportPlayer.matchMental}</td>
                  </tr>
                  <tr>
                    <td style={{ border: '1px solid #111', padding: '7px 12px' }}>Semangat Bermain (Spirit)</td>
                    <td className="center" style={{ border: '1px solid #111', padding: '7px 12px', textAlign: 'center', fontWeight: 'bold' }}>{activeReportPlayer.spirit}</td>
                  </tr>
                  <tr>
                    <td style={{ border: '1px solid #111', padding: '7px 12px' }}>Daya Tahan Fisik (Endurance Cardio)</td>
                    <td className="center" style={{ border: '1px solid #111', padding: '7px 12px', textAlign: 'center', fontWeight: 'bold' }}>{activeReportPlayer.endurance}</td>
                  </tr>
                  <tr style={{ backgroundColor: '#f8fafc', fontWeight: 'extrabold' }}>
                    <td style={{ border: '1px solid #111', padding: '9px 12px', textTransform: 'uppercase' }}>Rata-Rata Nilai Keseluruhan</td>
                    <td className="center text-emerald-600" style={{ border: '1px solid #111', padding: '9px 12px', textAlign: 'center', fontSize: '15px' }}>
                      {getAverageScore(activeReportPlayer)} / 100
                    </td>
                  </tr>
                </tbody>
              </table>

              {/* Kolom Deskripsi dan Catatan */}
              <div className="catatan" style={{ border: '1px solid #111', padding: '12px', marginTop: '20px', borderRadius: '4px' }}>
                <div className="catatan-title" style={{ fontWeight: 'bold', marginBottom: '6px' }}>Catatan khusus & Rencana Tindak Lanjut:</div>
                <p style={{ margin: 0, fontStyle: 'italic', fontSize: '13px' }}>{activeReportPlayer.notes}</p>
              </div>

              {/* Tanda Tangan dari presiden/penasehat team dan head coach */}
              <div className="ttd-box flex justify-between gap-12 text-center" style={{ display: 'flex', justifyContent: 'space-between', marginTop: '40px', fontSize: '13px' }}>
                <div className="ttd-col" style={{ width: '40%', display: 'inline-block' }}>
                  <div>Mengetahui,</div>
                  <div style={{ fontWeight: 'bold', textDecoration: 'underline', marginTop: '55px' }}>{management.president}</div>
                  <div style={{ fontSize: '11px', color: '#444' }}>Presiden / Penasehat Team</div>
                </div>
                <div className="ttd-col" style={{ width: '40%', display: 'inline-block' }}>
                  <div>Disetujui oleh,</div>
                  <div style={{ fontWeight: 'bold', textDecoration: 'underline', marginTop: '55px' }}>{management.headCoach}</div>
                  <div style={{ fontSize: '11px', color: '#444' }}>Head Coach AL FARABY FC</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
