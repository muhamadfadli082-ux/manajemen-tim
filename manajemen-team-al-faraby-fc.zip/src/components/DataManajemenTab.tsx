/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Management } from '../types';
import { Shield, Mail, Phone, MapPin, Edit3, Save, X, Award, Briefcase, HeartHandshake } from 'lucide-react';
import { motion } from 'motion/react';

interface DataManajemenTabProps {
  management: Management;
  onUpdateManagement: (data: Management) => void;
  playerCount: number;
}

export default function DataManajemenTab({
  management,
  onUpdateManagement,
  playerCount
}: DataManajemenTabProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<Management>({ ...management });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateManagement(formData);
    setIsEditing(false);
  };

  const infoFields = [
    { label: 'Nama Tim', key: 'teamName', icon: '⚽' },
    { label: 'Alamat Tim', key: 'address', icon: '📍' },
    { label: 'Presiden / Penasehat', key: 'president', icon: '👑' },
    { label: 'Kepala Sekolah', key: 'principal', icon: '🏫' },
    { label: 'Head Coach (Pelatih Utama)', key: 'headCoach', icon: '📋' },
    { label: 'Coach (Asisten Pelatih)', key: 'coach', icon: '🏃' },
    { label: 'Manajer Operasional 1', key: 'manager1', icon: '💼' },
    { label: 'Manajer Humas 2', key: 'manager2', icon: '👥' },
    { label: 'Staff Logistik 1', key: 'staff1', icon: '📦' },
    { label: 'Staff Admin 2', key: 'staff2', icon: '📁' },
    { label: 'NPSN Sekolah', key: 'npsn', icon: '🔍' },
    { label: 'Email Resmi', key: 'email', icon: '✉️' },
  ] as const;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold font-sans text-white uppercase tracking-wide">
            Struktur Manajemen AL FARABY FC
          </h2>
          <p className="text-xs text-gray-400 font-mono">Informasi resmi pimpinan, kepelatihan, dan staff pendukung</p>
        </div>
        
        {!isEditing ? (
          <button
            onClick={() => { setFormData({ ...management }); setIsEditing(true); }}
            className="flex items-center gap-1.5 px-4 py-2 bg-teal-500 text-slate-950 font-bold text-xs rounded-xl hover:bg-teal-400 transition-all shadow-lg shadow-teal-500/10"
          >
            <Edit3 className="w-4 h-4" /> Edit Data Struktur
          </button>
        ) : (
          <div className="flex gap-2">
            <button
              onClick={() => setIsEditing(false)}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 text-gray-300 font-bold text-xs rounded-xl hover:bg-slate-700 transition-all"
            >
              <X className="w-4 h-4" /> Batal
            </button>
          </div>
        )}
      </div>

      {!isEditing ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card Ringkasan Skuad Utama */}
          <div className="md:col-span-1 bg-gradient-to-br from-slate-950 to-slate-900 border border-teal-500/20 p-6 rounded-2xl flex flex-col justify-between shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-teal-500/5 rounded-full blur-2xl"></div>
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-teal-400 font-bold uppercase font-mono text-xs tracking-wider">
                <Shield className="w-4 h-4" /> ID Entitas Terverifikasi
              </div>
              <div className="text-center py-6 bg-slate-900/60 rounded-xl border border-slate-800">
                <div className="text-5xl mb-2">🏆</div>
                <h3 className="text-lg font-bold text-teal-400 font-sans tracking-wide">{management.teamName}</h3>
                <p className="text-xs text-gray-500 font-mono mt-1">NPSN: {management.npsn}</p>
              </div>

              <div className="space-y-2 mt-4 text-xs font-mono">
                <div className="flex justify-between py-1.5 border-b border-slate-800">
                  <span className="text-gray-400">Total Pemain Aktif:</span>
                  <span className="text-teal-400 font-bold">{playerCount} Anak</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-800">
                  <span className="text-gray-400">Presiden Klub:</span>
                  <span className="text-white font-semibold">{management.president}</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-gray-400">Basis Sekolah:</span>
                  <span className="text-emerald-400 font-semibold">{management.principal}</span>
                </div>
              </div>
            </div>

            <div className="mt-8 p-3 rounded-lg bg-teal-500/10 border border-teal-500/30 text-[10px] text-teal-300 font-mono italic text-center leading-relaxed">
              "Kekuatan tim terletak pada disiplin moral dan kebugaran fisik yang bersinergi."
            </div>
          </div>

          {/* Grid Informasi Detail Struktur */}
          <div className="md:col-span-2 bg-slate-950/40 border border-slate-800/80 rounded-2xl p-6 shadow-xl">
            <h3 className="text-xs font-bold font-mono text-teal-400 uppercase tracking-wider mb-4 border-b border-slate-800 pb-2">
              Daftar Pejabat Resmi & Staff
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {infoFields.map((field) => (
                <div key={field.key} className="p-4 bg-slate-900/50 rounded-xl border border-slate-800 hover:border-slate-700/50 transition-all flex items-start gap-3">
                  <span className="text-xl p-2 bg-slate-950 rounded-lg">{field.icon}</span>
                  <div>
                    <label className="text-[10px] uppercase font-mono tracking-wider text-gray-500 block">{field.label}</label>
                    <span className="text-sm font-bold text-gray-200">{(management as any)[field.key]}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSave} className="bg-slate-900/40 border border-teal-500/30 rounded-2xl p-6 shadow-xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {infoFields.map((field) => (
              <div key={field.key} className="space-y-1">
                <label className="text-xs font-semibold text-teal-400 flex items-center gap-1.5">
                  <span>{field.icon}</span> {field.label}
                </label>
                <input
                  type="text"
                  required
                  value={(formData as any)[field.key]}
                  onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 px-3 text-sm text-gray-200 focus:outline-none focus:ring-1 focus:ring-teal-500 focus:border-teal-500"
                />
              </div>
            ))}
          </div>

          <div className="mt-8 pt-4 border-t border-slate-800 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 bg-slate-800 text-gray-300 font-bold text-xs rounded-xl hover:bg-slate-700 transition"
            >
              Batal
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-6 py-2 bg-teal-500 text-slate-950 font-bold text-xs rounded-xl hover:bg-teal-400 transition"
            >
              <Save className="w-4 h-4" /> Simpan Perubahan
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
