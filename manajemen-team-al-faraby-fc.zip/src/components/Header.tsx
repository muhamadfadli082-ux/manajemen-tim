/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Menu, Sun, Moon, Sparkles, User, Bell, LayoutGrid } from 'lucide-react';
import { UserRole } from '../types';

interface HeaderProps {
  isSidebarOpen: boolean;
  onToggleSidebar: () => void;
  activeTab: string;
  onTabChange: (tabId: string) => void;
  role: UserRole;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  teamName: string;
}

export default function Header({
  isSidebarOpen,
  onToggleSidebar,
  activeTab,
  onTabChange,
  role,
  isDarkMode,
  onToggleDarkMode,
  teamName
}: HeaderProps) {
  const [timeStr, setTimeStr] = useState('');

  // Clock runner
  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' WIB');
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  // Menu utama/tab atas sesuai request ("dashboard menu beserta tab atas")
  const mainTabs = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'dataManajemen', label: 'Manajemen' },
    { id: 'dataPemain', label: 'Roster Skuat' },
    { id: 'jadwal', label: 'Agenda & Laga' },
    { id: 'penilaian', label: 'Rapor Penilaian' }
  ];

  // Saring tab atas berdasarkan role agar tidak merusak privilege
  const getAllowedTabs = () => {
    if (role === 'admin') return mainTabs;
    if (role === 'user') {
      return mainTabs.filter(t => ['dataPemain', 'dataManajemen', 'penilaian'].includes(t.id));
    }
    // Wali murid
    return mainTabs.filter(t => ['dashboard', 'dataPemain', 'penilaian'].includes(t.id));
  };

  const allowedTabs = getAllowedTabs();

  return (
    <header className="h-16 border-b border-slate-900 bg-[#020617]/90 backdrop-blur-md flex items-center justify-between px-6 sticky top-0 z-30 shadow-md">
      {/* Sisi Kiri: Sidebar toggler & Judul Pendek */}
      <div className="flex items-center gap-4">
        {!isSidebarOpen && (
          <button
            onClick={onToggleSidebar}
            className="p-1 px-1.5 bg-slate-950 border border-slate-800 hover:text-white rounded-lg text-gray-400 hover:bg-slate-900 transition flex items-center justify-center gap-1.5"
            title="Tampilkan Sidebar"
          >
            <Menu className="w-4 h-4" />
            <span className="text-[10px] uppercase font-bold font-mono tracking-wider hidden sm:inline">MENU</span>
          </button>
        )}
        
        <div className="flex items-center gap-1.5 text-xs font-mono bg-slate-950 border border-slate-850 px-3 py-1 rounded-full text-teal-400 select-none">
          <Sparkles className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '6s' }} />
          <span>SD ISLAM AL FARABY FC</span>
        </div>
      </div>

      {/* Sisi Tengah: Tab Atas (Menu Utama) - untuk Desktop */}
      <div className="hidden lg:flex items-center gap-1 bg-slate-950 p-1 border border-slate-900 rounded-xl max-w-lg">
        {allowedTabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`px-4 py-1.5 text-xs font-bold uppercase transition rounded-lg ${
              activeTab === tab.id
                ? 'bg-teal-500 text-slate-950 font-black shadow-lg shadow-teal-500/15'
                : 'text-gray-400 hover:text-white hover:bg-slate-900/50'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Sisi Kanan: Jam, Mode Switch, dan Profile */}
      <div className="flex items-center gap-4 text-xs">
        <span className="font-mono text-gray-400 hidden sm:inline-block border-r border-slate-800 pr-4">
          ⏰ {timeStr || '09:30:11 WIB'}
        </span>

        {/* Toggles Ganti Mode / Dark Mode Toggle */}
        <button
          onClick={onToggleDarkMode}
          className="p-2 cursor-pointer bg-slate-950 border border-slate-850 rounded-lg text-teal-400 hover:text-white hover:bg-slate-900 transition"
          title={isDarkMode ? 'Ganti Mode Terang' : 'Ganti Mode Gelap'}
        >
          {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* Akun Avatar */}
        <div className="flex items-center gap-2 border-l border-slate-800 pl-4">
          <div className="w-7.5 h-7.5 rounded-full bg-slate-950 border border-teal-500/30 flex items-center justify-center font-bold text-teal-400 uppercase select-none">
            {role.substring(0, 2)}
          </div>
          <span className="font-mono font-bold text-gray-300 hidden md:inline truncate max-w-[80px]">
            {role === 'admin' ? 'Ustadz Fadli' : role === 'user' ? 'Ustadz Fauzi' : 'Wali Murid'}
          </span>
        </div>
      </div>
    </header>
  );
}
