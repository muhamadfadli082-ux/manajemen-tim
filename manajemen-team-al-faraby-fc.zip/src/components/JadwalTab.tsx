/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Schedule, UserRole } from '../types';
import { Plus, Save, X, Calendar, MapPin, Award, Dumbbell, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

interface JadwalTabProps {
  schedules: Schedule[];
  role: UserRole;
  onAddSchedule: (schedule: Omit<Schedule, 'id'>) => void;
  onUpdateScore: (id: string, myScore: number, opponentScore: number) => void;
}

export default function JadwalTab({
  schedules,
  role,
  onAddSchedule,
  onUpdateScore
}: JadwalTabProps) {
  // Modal / Form states
  const [showAddModal, setShowAddModal] = useState(false);
  const [showScoreModal, setShowScoreModal] = useState(false);
  const [selectedScheduleId, setSelectedScheduleId] = useState<string | null>(null);

  // Add agenda inputs
  const [title, setTitle] = useState('');
  const [type, setType] = useState<'Latihan' | 'Sparring' | 'Resmi'>('Latihan');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [location, setLocation] = useState('');
  const [menu, setMenu] = useState('');
  const [opponent, setOpponent] = useState('');

  // Sparing / Match scores inputs
  const [myScore, setMyScore] = useState<number>(0);
  const [opponentScore, setOpponentScore] = useState<number>(0);

  const isAdmin = role === 'admin';

  const handleOpenScoreModal = (sched: Schedule) => {
    setSelectedScheduleId(sched.id);
    setMyScore(sched.myScore || 0);
    setOpponentScore(sched.opponentScore || 0);
    setShowScoreModal(true);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !date || !time || !location) return;

    onAddSchedule({
      title,
      type,
      date,
      time,
      location,
      menu: type === 'Latihan' ? menu : undefined,
      opponent: type !== 'Latihan' ? opponent : undefined,
      myScore: type !== 'Latihan' ? 0 : undefined,
      opponentScore: type !== 'Latihan' ? 0 : undefined,
      completed: false
    });

    setShowAddModal(false);
    // Reset Form
    setTitle('');
    setType('Latihan');
    setDate('');
    setTime('');
    setLocation('');
    setMenu('');
    setOpponent('');
  };

  const handleScoreSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedScheduleId) return;

    onUpdateScore(selectedScheduleId, myScore, opponentScore);
    setShowScoreModal(false);
    setSelectedScheduleId(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold font-sans text-white uppercase tracking-wide flex items-center gap-2">
            📅 Agenda & Jadwal Resmi Al Faraby
          </h2>
          <p className="text-xs text-gray-400 font-mono">Daftar latihan, latih tanding (sparring), dan laga kejuaraan</p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-4, py-2 bg-teal-500 text-slate-950 font-bold text-xs rounded-xl hover:bg-teal-400 transition shadow-lg shadow-teal-500/10"
          >
            <Plus className="w-3.5 h-3.5" /> Buat Agenda Baru
          </button>
        )}
      </div>

      {/* Grid List Agenda Card */}
      {schedules.length === 0 ? (
        <div className="text-center py-16 bg-slate-950/20 border border-dashed border-slate-850 rounded-2xl">
          <Calendar className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-sm text-gray-400 font-mono">Belum ada agenda latih tanding atau latihan yang tercatat.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {schedules.map((item) => {
            const isMatch = item.type === 'Sparring' || item.type === 'Resmi';
            return (
              <motion.div
                key={item.id}
                whileHover={{ scale: 1.01 }}
                className={`bg-slate-900/60 rounded-2xl border p-5 flex flex-col justify-between transition-all relative ${
                  item.completed 
                    ? 'border-slate-850 opacity-90' 
                    : item.type === 'Latihan' 
                      ? 'border-teal-500/20 shadow-lg shadow-teal-500/5' 
                      : 'border-rose-500/20 shadow-lg shadow-rose-500/5'
                }`}
              >
                {/* Header Card */}
                <div className="flex justify-between items-start mb-3">
                  <span className={`px-2.5 py-1 rounded text-[9px] font-mono font-bold uppercase tracking-wider ${
                    item.type === 'Latihan' ? 'bg-teal-500/10 text-teal-400 border border-teal-500/20' :
                    item.type === 'Sparring' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                    'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                  }`}>
                    {item.type}
                  </span>
                  <span className="text-[11px] text-gray-400 font-mono">
                    📆 {item.date} • {item.time} WIB
                  </span>
                </div>

                {/* Body Card */}
                <div className="space-y-3 mt-1.5 flex-1">
                  <h3 className="text-sm font-bold text-white uppercase font-sans tracking-wide">
                    {item.title}
                  </h3>
                  
                  <div className="text-xs text-gray-300 font-mono space-y-1">
                    <p className="flex items-center gap-1.5">
                      📍 <span className="text-gray-400">{item.location}</span>
                    </p>
                  </div>

                  {item.type === 'Latihan' && item.menu && (
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-900 mt-2 flex gap-2 items-start">
                      <span className="text-lg p-1 bg-slate-900 rounded-lg">🏋️</span>
                      <div>
                        <span className="text-[10px] font-bold font-mono text-teal-400 block uppercase">Materi Latihan</span>
                        <p className="text-[11px] text-gray-300 leading-relaxed italic">{item.menu}</p>
                      </div>
                    </div>
                  )}

                  {isMatch && (
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-900 mt-2 flex flex-col items-center">
                      <span className="text-[10px] font-bold font-mono text-rose-400 uppercase tracking-widest mb-1.5">Papan Skor</span>
                      <div className="flex items-center justify-center gap-4 py-1.5 w-full">
                        <div className="text-center flex-1">
                          <div className="text-[10px] font-bold text-gray-500 font-mono">AL FARABY</div>
                          <span className="text-base font-black text-white">
                            {item.completed ? (item.myScore !== undefined ? item.myScore : 0) : '-'}
                          </span>
                        </div>
                        <span className="text-xs font-mono text-gray-500 font-bold">VS</span>
                        <div className="text-center flex-1">
                          <div className="text-[10px] font-bold text-rose-400 font-mono truncate max-w-[80px] mx-auto">{item.opponent || 'Lawan'}</div>
                          <span className="text-base font-black text-rose-400">
                            {item.completed ? (item.opponentScore !== undefined ? item.opponentScore : 0) : '-'}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Footer and Score Input Button */}
                <div className="mt-5 pt-3 border-t border-slate-800/60 flex justify-between items-center">
                  <span className="text-[9px] font-mono text-gray-500">ID: {item.id}</span>
                  
                  <div>
                    {isMatch && isAdmin && !item.completed && (
                      <button
                        onClick={() => handleOpenScoreModal(item)}
                        className="px-3 py-1 bg-rose-500 text-slate-950 text-[10px] font-bold uppercase rounded hover:bg-rose-400 transition"
                      >
                        Input Skor Laga
                      </button>
                    )}
                    {isMatch && isAdmin && item.completed && (
                      <button
                        onClick={() => handleOpenScoreModal(item)}
                        className="px-2.5 py-1 bg-slate-950 hover:bg-slate-900 text-gray-400 border border-slate-800 hover:text-white text-[10px] font-bold uppercase rounded transition"
                      >
                        Update Skor
                      </button>
                    )}
                    {!isMatch && (
                      <span className="text-[10px] font-mono text-teal-400 uppercase tracking-wider font-bold">
                        {item.completed ? '✓ Selesai' : '⏳ Mendatang'}
                      </span>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* MODAL INPUT AGENDA BARU */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-lg bg-slate-900 border border-teal-500/40 rounded-2xl p-6 shadow-2xl space-y-4"
          >
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-teal-400 animate-spin" /> Buat Agenda Skuad Baru
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-4 text-left">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-teal-400">Judul Agenda / Nama Kegiatan:</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Drill Passing Pendek atau Perebutan Piala Kemerdekaan"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-teal-400">Jenis Agenda:</label>
                  <select
                    value={type}
                    onChange={(e: any) => setType(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200"
                  >
                    <option value="Latihan">Latihan Tim Rutin</option>
                    <option value="Sparring">Sparring (Persahabatan)</option>
                    <option value="Resmi">Pertandingan Resmi (Turnamen)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-teal-400">Lokasi Kegiatan:</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Lapangan Al Faraby"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-teal-400">Tanggal Kegiatan:</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-teal-400">Waktu Mulai (WIB):</label>
                  <input
                    type="time"
                    required
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200"
                  />
                </div>
              </div>

              {type === 'Latihan' ? (
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-teal-400">Materi / Menu Latihan:</label>
                  <textarea
                    placeholder="Masukkan materi latihan secara detail..."
                    value={menu}
                    onChange={(e) => setMenu(e.target.value)}
                    rows={3}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200"
                  />
                </div>
              ) : (
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-teal-400">Lawan Sparring / Turnamen:</label>
                  <input
                    type="text"
                    required
                    placeholder="Nama institusi atau nama tim lawan..."
                    value={opponent}
                    onChange={(e) => setOpponent(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-xs text-gray-200"
                  />
                </div>
              )}

              <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-850 hover:bg-slate-800 text-gray-400 text-xs rounded-lg transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-500 text-slate-950 font-bold text-xs rounded-lg hover:bg-teal-400 transition"
                >
                  Simpan Agenda Skuad
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* MODAL INPUT HASIL SKOR PERTANDINGAN SAKRAL */}
      {showScoreModal && selectedScheduleId && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-sm bg-slate-900 border border-teal-500/40 rounded-2xl p-6 shadow-2xl space-y-4"
          >
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-1.5">
                🏆 Masukkan Skor Hasil Laga
              </h3>
              <button
                onClick={() => setShowScoreModal(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleScoreSubmit} className="space-y-5 text-center">
              <div className="grid grid-cols-2 gap-6 p-4 bg-slate-950 rounded-xl border border-slate-850">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold font-mono text-gray-500 uppercase">AL FARABY FC</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={myScore}
                    onChange={(e) => setMyScore(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg text-center font-black text-xl py-2 text-white focus:outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold font-mono text-rose-400 uppercase">TIM LAWAN</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={opponentScore}
                    onChange={(e) => setOpponentScore(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg text-center font-black text-xl py-2 text-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="text-[10px] text-gray-500 font-mono italic">
                * Skor yang disimpan akan memperbarui histori performa tim dan menyematkannya ke log publik.
              </div>

              <div className="flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowScoreModal(false)}
                  className="px-3.5 py-1.5 bg-slate-850 hover:bg-slate-800 text-gray-400 text-xs rounded-lg transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 bg-teal-500 text-slate-950 font-bold text-xs rounded-lg hover:bg-teal-400 transition"
                >
                  Simpan Hasil Skor Laga
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
}
