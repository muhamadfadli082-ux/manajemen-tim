/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { Player, Assessment, UserRole } from '../types';
import { Download, UploadCloud, FileSpreadsheet, FileText, CheckCircle2, AlertTriangle, ShieldCheck, HelpCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface EksporImporTabProps {
  players: Player[];
  assessments: Assessment[];
  role: UserRole;
  onImportPlayers: (importedPlayers: Player[]) => void;
  onImportAssessments: (importedAssessments: Assessment[]) => void;
}

export default function EksporImporTab({
  players,
  assessments,
  role,
  onImportPlayers,
  onImportAssessments
}: EksporImporTabProps) {
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [dragActive, setDragActive] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isAdmin = role === 'admin';

  // HELPER MOCK TEMPLATE CSV DOWNLOAD
  const handleDownloadTemplate = () => {
    // Header gabungan data pemain & data penilaian sesuai request!
    const csvContent = 
      "ID,Nama Lengkap,Tanggal Lahir,Posisi Skuad,Kelas Siswa,Berat Badan,Tinggi Badan,Pengetahjuan Sepakbola,passing,dribbling,control,shooting,kerjasama_tim,mental,spirit,dayat_tahan,catatan_deskripsi\n" +
      "P99,Siswa Contoh Al Faraby,2014-03-24,Penyerang,Siswa Kelas 5A,39 kg,142 cm,85,90,80,85,90,88,85,90,82,Pemain berbakat fisik kuat.";
    
    downloadFile(csvContent, "AlFarabyFC_Template_Gabungan.csv", "text/csv;charset=utf-8;");
    setSuccessMsg('Berkas template pengisian dikoordinasikan. Unduhan dimulai!');
  };

  const downloadFile = (content: string, fileName: string, contentType: string) => {
    const blob = new Blob([content], { type: contentType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", fileName);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // EKSPOR GABUNGAN KE EXCEL/CSV
  const handleExportExcelCombined = () => {
    if (players.length === 0) {
      setErrorMsg('Gagal Ekspor. Database pemain kosong.');
      return;
    }

    let csvContent = "ID,Nama Lengkap,Tanggal Lahit,Posisi Skuad,Kelas Siswa,Berat,Tinggi,Pengetahuan,Passing,Dribbling,Control,Shooting,Kerjasama Tim,Mental,Spirit,Daya Tahan,Catatan Evaluasi\n";
    
    players.forEach(p => {
      // Cari nilai evaluasi yang sesuai jika ada
      const val = assessments.find(a => a.playerId === p.id) || {
        knowledge: 0, passing: 0, dribbling: 0, control: 0, shooting: 0,
        teamwork: 0, matchMental: 0, spirit: 0, endurance: 0, notes: 'Belum dievaluasi'
      };

      const row = [
        p.id,
        `"${p.name}"`,
        p.birthdate,
        p.position,
        p.className || '',
        p.weight || '',
        p.height || '',
        val.knowledge,
        val.passing,
        val.dribbling,
        val.control,
        val.shooting,
        val.teamwork,
        val.matchMental,
        val.spirit,
        val.endurance,
        `"${val.notes.replace(/"/g, '""')}"`
      ].join(",");

      csvContent += row + "\n";
    });

    downloadFile(csvContent, `Data_Gabungan_AlFaraby_FC_${new Date().toISOString().slice(0,10)}.csv`, "text/csv;charset=utf-8;");
    setSuccessMsg('Ekspor Excel gabungan database sukses diterbitkan.');
  };

  // IMPOR DATA EXCEL/CSV PARSER
  const handleFileUpload = (file: File) => {
    setErrorMsg('');
    setSuccessMsg('');
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        if (!text) {
          setErrorMsg('File kosong atau rusak.');
          return;
        }

        const lines = text.split('\n');
        if (lines.length <= 1) {
          setErrorMsg('Data tidak memadai. Mohon periksa kembali baris file Anda.');
          return;
        }

        const newPlayers: Player[] = [];
        const newAssessments: Assessment[] = [];

        // Parsing baris demi baris, melewati header baris ke-0
        for (let i = 1; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;

          // Parsing sederhana pencocokan koma, mengabaikan koma di dalam tanda kutip
          const parts = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
          if (parts.length < 4) continue;

          const pId = parts[0] || 'PL-IMP-' + Math.random().toString(36).substring(2, 6).toUpperCase();
          const pName = (parts[1] || 'Siswa Tanpa Nama').replace(/"/g, '');
          const pBirth = parts[2] || '2014-01-01';
          const pPosRaw = parts[3] || 'Penyerang';
          let pPos: Player['position'] = 'Penyerang';
          if (pPosRaw.includes('Bek') || pPosRaw.includes('Def')) pPos = 'Bek';
          else if (pPosRaw.includes('Gel') || pPosRaw.includes('Mid')) pPos = 'Gelandang';
          else if (pPosRaw.includes('Kip') || pPosRaw.includes('Goa')) pPos = 'Kiper';

          // Dorong ke penampung Pemain
          newPlayers.push({
            id: pId,
            name: pName,
            birthdate: pBirth,
            position: pPos,
            photo: '👤',
            className: (parts[4] || 'Kelas Impor').replace(/"/g, ''),
            weight: parts[5] || '40 kg',
            height: parts[6] || '145 cm',
            phone: '0812'
          });

          // Jika kolom assessment terisi, dorong ke penampung Nilai
          if (parts[7] !== undefined && parts[7].trim() !== "") {
            newAssessments.push({
              id: 'EV-IMP-' + Math.random().toString(36).substring(2, 6).toUpperCase(),
              playerId: pId,
              playerName: pName,
              date: new Date().toISOString().slice(0, 10),
              knowledge: parseInt(parts[7]) || 80,
              passing: parseInt(parts[8]) || 80,
              dribbling: parseInt(parts[9]) || 80,
              control: parseInt(parts[10]) || 80,
              shooting: parseInt(parts[11]) || 80,
              individualSkill: 80,
              vision: 80,
              response: 80,
              jump: 80,
              teamwork: parseInt(parts[12]) || 80,
              matchMental: parseInt(parts[13]) || 80,
              spirit: parseInt(parts[14]) || 80,
              endurance: parseInt(parts[15]) || 80,
              notes: (parts[16] || 'Nilai dimasukkan dari sistem integrasi data excel.').replace(/"/g, ''),
              evaluator: 'Impor Eksternal'
            });
          }
        }

        if (newPlayers.length > 0) {
          onImportPlayers(newPlayers);
          if (newAssessments.length > 0) {
            onImportAssessments(newAssessments);
          }
          setSuccessMsg(`Berhasil mengimpor ${newPlayers.length} data Pemain dan ${newAssessments.length} lembar Rapor Nilai dari Excel!`);
        } else {
          setErrorMsg('Gagal mengurai file. Pastikan struktur kolom cocok dengan template.');
        }

      } catch (err: any) {
        setErrorMsg('Gagal memproses file CSV: ' + err.message);
      }
    };
    reader.readAsText(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold font-sans text-white uppercase tracking-wide flex items-center gap-2">
            📂 Ekspor & Impor Database Terpadu
          </h2>
          <p className="text-xs text-gray-400 font-mono">
            Migrasi database gabungan Skuat Pemain & Rapor Nilai dalam format Microsoft Excel / CSV
          </p>
        </div>
      </div>

      {successMsg && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 rounded-xl bg-teal-500/10 border border-teal-500/30 text-teal-400 text-xs font-mono font-bold flex items-center gap-2"
        >
          <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0" />
          <span>{successMsg}</span>
        </motion.div>
      )}

      {errorMsg && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-mono font-bold flex items-center gap-2"
        >
          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMsg}</span>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Sisi Kiri: Panel Download Ekspor */}
        <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800/80 space-y-6 text-left flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-teal-400">
              <FileSpreadsheet className="w-5 h-5" />
              <h3 className="text-sm font-bold font-mono uppercase tracking-wider">Ekspor Database Skuad</h3>
            </div>
            
            <p className="text-xs text-gray-400 leading-relaxed font-mono">
              Eksportir ini akan menggabungkan database data pemain beserta riwayat rekam penilaian fisiknya menjadi satu rangkuman file Excel (<code className="text-white">.csv</code>) yang siap disunting di komputer Anda.
            </p>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-850 space-y-2 text-xs font-mono">
              <div className="flex justify-between border-b border-slate-900 pb-1.5">
                <span className="text-gray-500">Record Pemain Terhitung:</span>
                <span className="text-white font-bold">{players.length} Orang</span>
              </div>
              <div className="flex justify-between border-b border-slate-900 pb-1.5">
                <span className="text-gray-500">Lembar Penilaian Cocok:</span>
                <span className="text-white font-bold">{assessments.length} Dokumen</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500 font-bold uppercase text-teal-400">Kompatibilitas:</span>
                <span className="text-white font-semibold">MS EXCEL / NUMBERS</span>
              </div>
            </div>
          </div>

          <div className="space-y-3 pt-6 border-t border-slate-800/85">
            <button
              onClick={handleExportExcelCombined}
              className="w-full py-3 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-xl transition flex items-center justify-center gap-2 shadow-lg shadow-teal-500/10"
            >
              <Download className="w-4 h-4" /> Ekspor ke Excel (CSV)
            </button>
            <button
              onClick={handleDownloadTemplate}
              className="w-full py-2.5 bg-slate-950 border border-slate-800 hover:border-slate-700 text-gray-400 hover:text-white font-bold text-xs uppercase tracking-wider rounded-xl transition flex items-center justify-center gap-2"
            >
              <FileText className="w-4 h-4" /> Unduh Berkas Template Baru
            </button>
          </div>
        </div>

        {/* Sisi Kanan: Panel Upload Impor (Drag Drop) */}
        <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800/80 space-y-6 text-left">
          <div className="flex justify-between items-center border-b border-slate-850 pb-2">
            <div className="flex items-center gap-2 text-teal-400">
              <UploadCloud className="w-5 h-5 text-teal-400" />
              <h3 className="text-sm font-bold font-mono uppercase tracking-wider">Impor Roster Baru</h3>
            </div>
            
            <span className="text-[9px] font-mono text-gray-500 uppercase">Input Gabungan</span>
          </div>

          {!isAdmin ? (
            <div className="py-16 text-center space-y-3 p-4 bg-slate-950/60 rounded-xl border border-slate-850">
              <span className="text-3xl">🛡️</span>
              <p className="text-xs text-gray-400 font-mono">
                Fitur impor database roster dikoordinasikan secara penuh hanya oleh pimpinan dengan akun Administrator.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-xs text-gray-400 leading-relaxed font-mono">
                Masukkan file roster atau rapor gabungan hasil olahan offline Anda. Sistem akan mem-parsing otomatis seluruh baris siswa.
              </p>

              {/* Drag and drop area */}
              <div
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center gap-3 cursor-pointer transition-all ${
                  dragActive 
                    ? 'border-teal-400 bg-teal-500/5' 
                    : 'border-slate-800 hover:border-teal-500/30 hover:bg-slate-950/20'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,.txt"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
                />
                
                <UploadCloud className="w-8 h-8 text-teal-400 animate-bounce" />
                
                <div className="text-center font-mono text-xs">
                  <span className="text-white block font-bold">Pilih File XLSX / CSV Anda</span>
                  <span className="text-gray-500 text-[10px] mt-1 block">Atau seret dan lepaskan file ke sini</span>
                </div>
              </div>

              <div className="p-3.5 bg-slate-950 border border-slate-850 rounded-xl leading-relaxed text-[10px] font-mono">
                <h4 className="text-teal-400 font-bold uppercase mb-1 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> Jaminan Integritas:
                </h4>
                <p className="text-gray-500">
                  Sistem perlindungan ganda Al Faraby mendeteksi duplikasi ID murid secara otomatis. Murid dengan ID yang sama di spreadsheet akan ditingkatkan nilainya (diupdate) tanpa menggandakan baris.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
