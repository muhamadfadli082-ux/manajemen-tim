/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  LayoutDashboard, 
  Settings, 
  HardDriveDownload, 
  Users, 
  Calendar, 
  Award, 
  RefreshCw, 
  Info, 
  LogOut, 
  ChevronLeft, 
  ChevronRight, 
  Activity
} from 'lucide-react';
import { UserRole } from '../types';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tabId: string) => void;
  isOpen: boolean;
  onToggle: () => void;
  role: UserRole;
  childName?: string;
  onLogout: () => void;
  teamName: string;
}

export default function Sidebar({
  activeTab,
  onTabChange,
  isOpen,
  onToggle,
  role,
  childName,
  onLogout,
  teamName
}: SidebarProps) {
  
  // Saring menu berdasarkan role user sesuai request!
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'dataManajemen', label: 'Data Manajemen', icon: Info },
    { id: 'dataPemain', label: 'Data Pemain', icon: Users },
    { id: 'jadwal', label: 'Jadwal & Agenda', icon: Calendar },
    { id: 'penilaian', label: 'Penilaian Rapor', icon: Award },
    { id: 'eksporImpor', label: 'Ekspor & Impor', icon: HardDriveDownload },
    { id: 'sinkron', label: 'Sinkron Sheets', icon: RefreshCw },
    { id: 'pengaturan', label: 'Pengaturan', icon: Settings },
  ];

  // Saring menu yang diizinkan untuk Coach / Wali Murid:
  // - Admin (semua)
  // - User (data pemain, data manajemen, penilaian, ekspor impor)
  // - Wali murid (data pemain-detail-biodata-wali, penilaian) -> dibatasi di dalam tab
  const getAllowedItems = () => {
    if (role === 'admin') return menuItems;
    if (role === 'user') {
      return menuItems.filter(item => 
        ['dataPemain', 'dataManajemen', 'penilaian', 'eksporImpor'].includes(item.id)
      );
    }
    // Wali Murid
    return menuItems.filter(item => 
      ['dashboard', 'dataPemain', 'penilaian'].includes(item.id)
    );
  };

  const allowedItems = getAllowedItems();

  const getRoleBadge = (r: UserRole) => {
    if (r === 'admin') return { text: 'ADMINISTRATOR', style: 'bg-teal-500/10 text-teal-400 border-teal-500/25' };
    if (r === 'user') return { text: 'PELATIH / USER', style: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/25' };
    return { text: 'WALI MURID', style: 'bg-amber-500/10 text-amber-400 border-amber-500/25' };
  };

  const badge = getRoleBadge(role);

  return (
    <aside
      className={`fixed top-0 left-0 h-screen bg-[#020617]/95 border-r border-slate-900 flex flex-col justify-between transition-all duration-300 z-40 shadow-2xl ${
        isOpen ? 'w-64' : 'w-16'
      }`}
    >
      {/* Sisi Atas: Logo & Collapse Button */}
      <div>
        <div className="h-16 flex items-center justify-between px-4 border-b border-slate-900">
          <div className={`flex items-center gap-3 overflow-hidden ${!isOpen ? 'justify-center w-full' : ''}`}>
            <span className="text-2xl animate-spin" style={{ animationDuration: '4s' }}>⚽</span>
            {isOpen && (
              <div className="text-left font-sans leading-none">
                <span className="text-sm font-black text-white block select-none uppercase tracking-tight">AL FARABY</span>
                <span className="text-[10px] font-bold text-teal-400 font-mono tracking-widest uppercase">FC SYSTEM</span>
              </div>
            )}
          </div>

          {/* Tombol Tampilkan/Sembunyikan Sidebar */}
          {isOpen && (
            <button
              onClick={onToggle}
              className="p-1 px-1.5 rounded-lg bg-slate-950 border border-slate-800 text-gray-400 hover:text-white transition"
              title="Sembunyikan Sidebar"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Informasi Akun Role */}
        <div className={`p-4 border-b border-slate-900 text-left ${!isOpen ? 'text-center' : ''}`}>
          {isOpen ? (
            <div className="space-y-1.5">
              <span className={`px-2.5 py-0.5 border text-[9px] font-mono font-bold rounded-full ${badge.style}`}>
                {badge.text}
              </span>
              {childName && (
                <div className="text-[10.5px] font-mono text-gray-400 mt-1 truncate">
                  Wali dari: <strong className="text-white">{childName}</strong>
                </div>
              )}
            </div>
          ) : (
            <span className="text-base select-none cursor-help" title={badge.text}>🛡️</span>
          )}
        </div>

        {/* Navigation Actions */}
        <nav className="p-3 space-y-1 text-left">
          {allowedItems.map((item) => {
            const Icon = item.icon;
            const isSelected = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`w-full flex items-center gap-3.5 py-2.5 px-3.5 rounded-xl text-xs font-semibold tracking-wide transition ${
                  isSelected
                    ? 'bg-gradient-to-r from-teal-500/10 to-slate-900 border-l-2 border-teal-400 text-white font-extrabold'
                    : 'text-gray-400 hover:text-white hover:bg-slate-950/40'
                }`}
              >
                <Icon className={`w-4 h-4 transition ${isSelected ? 'text-teal-400' : 'text-gray-500'}`} />
                {isOpen && <span>{item.label}</span>}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Sisi Bawah: Logout button */}
      <div className="p-3 border-t border-slate-900">
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3.5 py-2.5 px-3.5 rounded-xl text-xs font-semibold text-rose-400 hover:text-white hover:bg-rose-950/15 transition text-left"
        >
          <LogOut className="w-4 h-4 text-rose-400" />
          {isOpen && <span>Keluar Sistem</span>}
        </button>
      </div>
    </aside>
  );
}
