/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Player, Schedule, Management } from '../types';
import { Calendar, UserCheck, ShieldAlert, Award, ArrowUpRight, Plus, Target, Quote } from 'lucide-react';
import { motion } from 'motion/react';

interface DashboardTabProps {
  players: Player[];
  schedules: Schedule[];
  management: Management;
  onNavigateTab: (tabId: string) => void;
  openAddScheduleModal?: () => void;
  isDarkMode: boolean;
}

export default function DashboardTab({
  players,
  schedules,
  management,
  onNavigateTab,
  openAddScheduleModal,
  isDarkMode
}: DashboardTabProps) {
  // Hitung jumlah pemain berdasarkan posisi pemain
  const totalPlayers = players.length;
  const positions: Record<Player['position'], number> = {
    'Kiper': 0,
    'Bek': 0,
    'Gelandang': 0,
    'Penyerang': 0
  };

  players.forEach(p => {
    if (positions[p.position] !== undefined) {
      positions[p.position]++;
    }
  });

  const positionColors = {
    'Kiper': 'from-blue-500 to-cyan-400',
    'Bek': 'from-indigo-600 to-purple-500',
    'Gelandang': 'from-emerald-500 to-teal-400',
    'Penyerang': 'from-rose-500 to-amber-500'
  };

  const getPercentage = (count: number) => {
    if (totalPlayers === 0) return 0;
    return Math.round((count / totalPlayers) * 100);
  };

  // Ambil jadwal terdekat (yang belum completed)
  const sortedSchedules = [...schedules]
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  
  const upcomingSchedules = sortedSchedules.filter(s => !s.completed);
  const coreSchedulesToShow = upcomingSchedules.length > 0 ? upcomingSchedules : sortedSchedules;

  return (
    <div className="space-y-8">
      {/* KOP TENGAH ATAS DASHBOARD */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center pb-6 border-b border-dashed border-teal-500/20"
      >
        <div className="inline-flex items-center justify-center p-3 rounded-full bg-slate-900 border border-teal-500/30 text-teal-400 mb-2">
          <span className="text-4xl">⚽</span>
        </div>
        <h1 className="text-3xl font-extrabold font-sans tracking-tight text-white uppercase drop-shadow-[0_0_15px_rgba(20,184,166,0.3)]">
          {management.teamName}
        </h1>
        <p className="text-sm font-mono text-gray-400 tracking-wider">
          {management.address}
        </p>
        <div className="flex flex-wrap justify-center items-center gap-3 mt-3 text-xs font-mono text-gray-300">
          <span className="px-2.5 py-1 rounded bg-teal-500/10 border border-teal-500/20">
            Presiden: <strong className="text-teal-400">{management.president}</strong>
          </span>
          <span className="px-2.5 py-1 rounded bg-teal-500/10 border border-teal-500/20">
            NPSN: <strong className="text-indigo-400">{management.npsn}</strong>
          </span>
          <span className="px-2.5 py-1 rounded bg-teal-500/10 border border-teal-500/20">
            Email: <strong className="text-rose-400">{management.email}</strong>
          </span>
        </div>
      </motion.div>

      {/* METRIK STATISTIK FUTURISTIK & NEON */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Total Pemain (Dashboard Card 1) */}
        <motion.div
          whileHover={{ y: -4 }}
          className="bg-slate-900/60 p-5 rounded-2xl border border-teal-500/20 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <UserCheck className="w-20 h-20 text-teal-400" />
          </div>
          <div className="text-xs font-mono text-teal-400 tracking-wider uppercase mb-1">TOTAL SQUAD</div>
          <div className="text-4xl font-extrabold text-white font-sans">{totalPlayers}</div>
          <p className="text-xs text-gray-400 mt-2 font-mono">Pemain aktif terdaftar</p>
          <div className="mt-4 pt-3 border-t border-slate-800 flex justify-between items-center">
            <button
              onClick={() => onNavigateTab('dataPemain')}
              className="text-xs text-teal-400 font-semibold flex items-center hover:underline hover:text-teal-300"
            >
              Lihat Squad <ArrowUpRight className="ml-1 w-3.5 h-3.5" />
            </button>
          </div>
        </motion.div>

        {/* Persentase Bek (Dashboard Card 2) */}
        <motion.div
          whileHover={{ y: -4 }}
          className="bg-slate-900/60 p-5 rounded-2xl border border-indigo-500/20 relative overflow-hidden"
        >
          <div className="flex justify-between items-start">
            <div>
              <div className="text-xs font-mono text-indigo-400 tracking-wider uppercase mb-1">BEK (DEFENDER)</div>
              <div className="text-4xl font-extrabold text-white">{positions['Bek']}</div>
              <p className="text-xs text-gray-400 mt-2 font-mono">{getPercentage(positions['Bek'])}% dari skuad</p>
            </div>
            {/* Custom glowing circle */}
            <div className="relative w-12 h-12">
              <svg className="w-full h-full transform -rotate-90">
                <circle cx="24" cy="24" r="20" stroke="rgba(99, 102, 241, 0.15)" strokeWidth="4" fill="transparent" />
                <circle cx="24" cy="24" r="20" stroke="#6366f1" strokeWidth="4" fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 20}`}
                  strokeDashoffset={`${2 * Math.PI * 20 * (1 - getPercentage(positions['Bek']) / 100)}`}
                />
              </svg>
              <span className="absolute inset-0 flex items-center justify-center text-[10px] font-mono text-indigo-300 font-bold">DF</span>
            </div>
          </div>
        </motion.div>

        {/* Persentase Gelandang (Dashboard Card 3) */}
        <motion.div
          whileHover={{ y: -4 }}
          className="bg-slate-900/60 p-5 rounded-2xl border border-emerald-500/20 relative overflow-hidden"
        >
          <div className="flex justify-between items-start">
            <div>
              <div className="text-xs font-mono text-emerald-400 tracking-wider uppercase mb-1">GELANDANG (MID)</div>
              <div className="text-4xl font-extrabold text-white">{positions['Gelandang']}</div>
              <p className="text-xs text-gray-400 mt-2 font-mono">{getPercentage(positions['Gelandang'])}% dari skuad</p>
            </div>
            {/* Custom glowing circle */}
            <div className="relative w-12 h-12">
              <svg className="w-full h-full transform -rotate-90">
                <circle cx="24" cy="24" r="20" stroke="rgba(16, 185, 129, 0.15)" strokeWidth="4" fill="transparent" />
                <circle cx="24" cy="24" r="20" stroke="#10b981" strokeWidth="4" fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 20}`}
                  strokeDashoffset={`${2 * Math.PI * 20 * (1 - getPercentage(positions['Gelandang']) / 100)}`}
                />
              </svg>
              <span className="absolute inset-0 flex items-center justify-center text-[10px] font-mono text-emerald-300 font-bold">MF</span>
            </div>
          </div>
        </motion.div>

        {/* Persentase Penyerang (Dashboard Card 4) */}
        <motion.div
          whileHover={{ y: -4 }}
          className="bg-slate-900/60 p-5 rounded-2xl border border-rose-500/20 relative overflow-hidden"
        >
          <div className="flex justify-between items-start">
            <div>
              <div className="text-xs font-mono text-rose-400 tracking-wider uppercase mb-1">PENYERANG (FWD)</div>
              <div className="text-4xl font-extrabold text-white">{positions['Penyerang']}</div>
              <p className="text-xs text-gray-400 mt-2 font-mono">{getPercentage(positions['Penyerang'])}% dari skuad</p>
            </div>
            {/* Custom glowing circle */}
            <div className="relative w-12 h-12">
              <svg className="w-full h-full transform -rotate-90">
                <circle cx="24" cy="24" r="20" stroke="rgba(244, 63, 94, 0.15)" strokeWidth="4" fill="transparent" />
                <circle cx="24" cy="24" r="20" stroke="#f43f5e" strokeWidth="4" fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 20}`}
                  strokeDashoffset={`${2 * Math.PI * 20 * (1 - getPercentage(positions['Penyerang']) / 100)}`}
                />
              </svg>
              <span className="absolute inset-0 flex items-center justify-center text-[10px] font-mono text-rose-300 font-bold">FW</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* MOTIVASI PRESIDEN DAN LINK AKSES CEPAT */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Kata Motivasi Presiden */}
        <div className="lg:col-span-2 bg-gradient-to-r from-teal-950/40 to-slate-900/80 p-6 rounded-2xl border border-teal-500/40 flex flex-col justify-between shadow-lg relative">
          <div className="absolute top-4 right-4 text-teal-500/10">
            <Quote className="w-24 h-24" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-2xl">🎗️</span>
              <h3 className="text-sm font-bold font-mono text-teal-400 tracking-wide uppercase">Kata Motivasi Presiden Al Faraby</h3>
            </div>
            <p className="text-base font-medium font-sans text-gray-200 italic leading-relaxed relative z-10">
              “Kunci utama keberhasilan adalah pembinaan karakter, kedisiplinan beribadah, kesungguhan melatih fisik, dan kerjasama tim yang kokoh sejak dini.”
            </p>
          </div>
          <div className="mt-6 pt-4 border-t border-teal-800/30 text-xs font-mono text-gray-400 flex justify-between">
            <span>By: <strong>{management.president}</strong></span>
            <span>PRESIDEN / PENASEHAT</span>
          </div>
        </div>

        {/* Akses Cepat Menu */}
        <div className="bg-slate-900/60 p-6 rounded-2xl border border-slate-800/80 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold font-mono text-teal-400 tracking-wide uppercase mb-4">Akses Cepat Portal</h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => onNavigateTab('dataPemain')}
                className="p-3 rounded-lg bg-slate-950 border border-slate-800 hover:border-teal-500/50 hover:bg-slate-900 text-left transition-all text-xs"
              >
                👥 Squad Utama
              </button>
              <button
                onClick={() => onNavigateTab('jadwal')}
                className="p-3 rounded-lg bg-slate-950 border border-slate-800 hover:border-teal-500/50 hover:bg-slate-900 text-left transition-all text-xs"
              >
                📅 Jadwal Latihan
              </button>
              <button
                onClick={() => onNavigateTab('penilaian')}
                className="p-3 rounded-lg bg-slate-950 border border-slate-800 hover:border-teal-500/50 hover:bg-slate-900 text-left transition-all text-xs"
              >
                📝 Penilaian Fisik
              </button>
              <button
                onClick={() => onNavigateTab('sinkron')}
                className="p-3 rounded-lg bg-slate-950 border border-slate-800 hover:border-teal-500/50 hover:bg-slate-900 text-left transition-all text-xs"
              >
                ⚡ Sinkron Sheets
              </button>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-800 flex justify-between items-center text-xs text-gray-400">
            <span>SD ISLAM AL FARABY</span>
            <span className="text-[10px] font-mono text-teal-400">Secure Node</span>
          </div>
        </div>
      </div>

      {/* JADWAL LATIHAN ATAUPUN SPARRING */}
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-teal-400" />
            <h2 className="text-lg font-bold text-white uppercase font-sans tracking-wide">
              Agenda Latihan & Sparing Terdekat
            </h2>
          </div>
          {openAddScheduleModal && (
            <button
              onClick={openAddScheduleModal}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-teal-500 text-slate-950 text-xs font-bold rounded-lg hover:bg-teal-400 transition-all font-sans"
            >
              <Plus className="w-4 h-4" /> Tambah Agenda
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {coreSchedulesToShow.slice(0, 3).map((item) => {
            const isMatch = item.type === 'Sparring' || item.type === 'Resmi';
            return (
              <motion.div
                key={item.id}
                whileHover={{ scale: 1.01 }}
                className={`flex flex-col justify-between bg-slate-900/60 p-5 rounded-2xl border transition-all ${
                  item.completed 
                    ? 'border-gray-800' 
                    : item.type === 'Latihan' 
                      ? 'border-teal-500/30' 
                      : 'border-rose-500/30'
                }`}
              >
                {/* Header card agenda */}
                <div className="flex justify-between items-start mb-4">
                  <span className={`px-2.5 py-1 rounded text-[10px] font-mono font-bold uppercase ${
                    item.type === 'Latihan' 
                      ? 'bg-teal-500/10 text-teal-400 border border-teal-500/20' 
                      : item.type === 'Sparring'
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                  }`}>
                    {item.type}
                  </span>
                  <span className="text-xs text-gray-400 font-mono italic">
                    {item.date} • {item.time} WIB
                  </span>
                </div>

                {/* Info Utama */}
                <div className="space-y-2">
                  <h3 className="text-sm font-bold text-white">{item.title}</h3>
                  <p className="text-xs text-gray-300 font-mono flex items-center gap-1">
                    📌 {item.location}
                  </p>

                  {item.type === 'Latihan' && item.menu && (
                    <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800 mt-2">
                      <div className="text-[10px] font-bold font-mono text-teal-400 uppercase mb-1">Materi Latihan:</div>
                      <p className="text-[11px] text-gray-300 line-clamp-2 italic">{item.menu}</p>
                    </div>
                  )}

                  {isMatch && (
                    <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800 mt-2 flex flex-col items-center">
                      <div className="text-[10px] font-bold font-mono text-rose-400 uppercase mb-1">Pertandingan:</div>
                      <div className="flex items-center gap-3 text-xs">
                        <span className="font-bold text-teal-400">AL FARABY FC</span>
                        {item.completed && item.myScore !== undefined ? (
                          <span className="px-2 py-0.5 bg-slate-900 rounded font-mono font-extrabold text-white">
                            {item.myScore} - {item.opponentScore}
                          </span>
                        ) : (
                          <span className="text-[10px] text-gray-500 font-mono italic">BS (Belum Selesai)</span>
                        )}
                        <span className="font-bold text-rose-400">{item.opponent || 'Lawan'}</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Footer status */}
                <div className="mt-4 pt-3 border-t border-slate-800 flex justify-between items-center text-xs text-gray-500 font-mono">
                  <span>ID: {item.id}</span>
                  <span className={`font-bold transition-all ${item.completed ? 'text-gray-500' : 'text-teal-400 animate-pulse'}`}>
                    {item.completed ? '✓ Selesai' : '⏳ Terjadwal'}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
