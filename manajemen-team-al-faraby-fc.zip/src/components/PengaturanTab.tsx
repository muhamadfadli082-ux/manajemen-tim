/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Management, AppSettings } from '../types';
import { Settings, Save, Lock, Layout, Sparkles, Key, CheckCircle2, Image as ImageIcon, Search } from 'lucide-react';
import { motion } from 'motion/react';

interface PengaturanTabProps {
  management: Management;
  appSettings: AppSettings;
  customPasswords: { admin: string; user: string; wali: string };
  onUpdateManagement: (data: Management) => void;
  onUpdateAppSettings: (settings: Partial<AppSettings>) => void;
  onUpdatePasswords: (passwords: { admin: string; user: string; wali: string }) => void;
  role: 'admin' | 'user' | 'wali';
}

const LOGO_PRESETS = [
  { char: '⚽', name: 'Bola Klasik' },
  { char: '🏆', name: 'Piala Danone' },
  { char: '🛡️', name: 'Tameng Baja' },
  { char: '⭐', name: 'Bintang Emas' },
  { char: '👑', name: 'Mahkota Juara' },
  { char: '🤝', name: 'Solidaritas Tim' },
  { char: '🦁', name: 'Lions FC' },
  { char: '🦅', name: 'Garuda Al Faraby' }
];

export default function PengaturanTab({
  management,
  appSettings,
  customPasswords,
  onUpdateManagement,
  onUpdateAppSettings,
  onUpdatePasswords,
  role
}: PengaturanTabProps) {
  const [successMsg, setSuccessMsg] = useState('');
  
  // Form states - General Info
  const [teamName, setTeamName] = useState(management.teamName);
  const [address, setAddress] = useState(management.address);
  const [principal, setPrincipal] = useState(management.principal);
  const [npsn, setNpsn] = useState(management.npsn);
  const [logoInput, setLogoInput] = useState(management.logo);

  // Form states - Custom Passwords
  const [adminPass, setAdminPass] = useState(customPasswords.admin);
  const [userPass, setUserPass] = useState(customPasswords.user);
  const [waliPass, setWaliPass] = useState(customPasswords.wali);

  // Form states - Custom Background
  const [dashboardBg, setDashboardBg] = useState(appSettings.dashboardBg);
  const [openAssessment, setOpenAssessment] = useState(appSettings.openAssessmentToParents);

  // Drive/Local logo search states
  const [logoKeyword, setLogoKeyword] = useState('');
  const [logoSearchResults, setLogoSearchResults] = useState<Array<{ char: string; name: string }>>([]);
  const [isDriveLogoSearching, setIsDriveLogoSearching] = useState(false);

  const isAdmin = role === 'admin';

  const handleSaveInfo = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateManagement({
      ...management,
      teamName,
      address,
      principal,
      npsn,
      logo: logoInput
    });
    setSuccessMsg('Informasi dasar AL FARABY FC berhasil diselaraskan!');
    clearMsg();
  };

  const handleSaveSecurity = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdatePasswords({
      admin: adminPass,
      user: userPass,
      wali: waliPass
    });
    setSuccessMsg('Kredensial seluruh role pengguna berhasil dijaga dengan proteksi baru!');
    clearMsg();
  };

  const handleSaveStyles = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateAppSettings({
      dashboardBg,
      openAssessmentToParents: openAssessment
    });
    setSuccessMsg('Penampilan dashboard berhasil diarsiteki dengan opsi anyar!');
    clearMsg();
  };

  const clearMsg = () => {
    setTimeout(() => setSuccessMsg(''), 2500);
  };

  // Pencarian Logo Drive / Lokal
  const handleDriveLogoSearch = () => {
    setIsDriveLogoSearching(true);
    setTimeout(() => {
      const keyword = logoKeyword.toLowerCase();
      const results = LOGO_PRESETS.filter(logo =>
        logo.name.toLowerCase().includes(keyword)
      );
      setLogoSearchResults(results.length > 0 ? results : LOGO_PRESETS.slice(0, 3));
      setIsDriveLogoSearching(false);
    }, 500);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold font-sans text-white uppercase tracking-wide flex items-center gap-2">
            ⚙️ Pengaturan Pusat Sistem Al Faraby
          </h2>
          <p className="text-xs text-gray-400 font-mono">
            Modifikasi logo instansi, nama pimpinan sekolah, NPSN resmi, dan konfigurasi aksesibilitas
          </p>
        </div>
      </div>

      {successMsg && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 rounded-xl bg-teal-500/10 border border-teal-500/30 text-teal-400 text-xs font-mono font-bold flex items-center gap-2"
        >
          <CheckCircle2 className="w-4 h-4 text-teal-400" />
          <span>{successMsg}</span>
        </motion.div>
      )}

      {!isAdmin ? (
        <div className="py-20 text-center bg-slate-950/40 rounded-2xl border border-slate-850 space-y-4">
          <Lock className="w-12 h-12 text-slate-700 mx-auto" />
          <h3 className="text-sm font-bold uppercase font-mono text-gray-500">RUANG PENGATURAN TERKUNCI</h3>
          <p className="text-xs text-gray-400 max-w-sm mx-auto font-mono">
            Mohon maaf, modifikasi parameter dasar sekolah dilindungi dan hanya dapat dimasuki oleh akun Administrator.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Form 1: Informasi Dasar Instansi */}
          <div className="bg-slate-900/60 p-5 rounded-2xl border border-slate-850 space-y-4 text-left">
            <h3 className="text-xs font-bold font-mono text-teal-400 uppercase tracking-widest border-b border-slate-800 pb-2">
              Informasi Umum & Logo
            </h3>
            
            <form onSubmit={handleSaveInfo} className="space-y-4 text-xs font-sans">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="font-semibold text-gray-400">Nama Resmi Team:</label>
                  <input
                    type="text"
                    required
                    value={teamName}
                    onChange={(e) => setTeamName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-gray-200"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-gray-400">NPSN Sekolah:</label>
                  <input
                    type="text"
                    required
                    value={npsn}
                    onChange={(e) => setNpsn(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-gray-200"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-gray-400">Alamat Resmi:</label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-gray-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="font-semibold text-gray-400">Kepala Sekolah / Adv:</label>
                  <input
                    type="text"
                    required
                    value={principal}
                    onChange={(e) => setPrincipal(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-gray-200"
                  />
                </div>

                {/* Ganti Logo Team with Drive Seeker */}
                <div className="space-y-1">
                  <label className="font-semibold text-teal-400 flex justify-between items-center">
                    <span>Logo Team (Emoji/Karakter):</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={logoInput}
                    onChange={(e) => setLogoInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-gray-200 font-mono text-center text-lg"
                  />
                </div>
              </div>

              {/* Logo Finder Drive simulation */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-850 space-y-2 mt-2">
                <div className="text-[10px] uppercase font-mono tracking-wider text-gray-400 font-bold flex items-center justify-between">
                  <span>Drive Seeker Logo</span>
                  <span className="text-teal-400 text-[8px]">Google Integrasi OK</span>
                </div>
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    placeholder="Contoh: Bola, Tameng, Garuda..."
                    value={logoKeyword}
                    onChange={(e) => setLogoKeyword(e.target.value)}
                    className="flex-1 bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[10px] text-gray-300"
                  />
                  <button
                    type="button"
                    onClick={handleDriveLogoSearch}
                    className="px-2.5 py-1 bg-teal-500 text-slate-950 text-[10px] font-bold rounded"
                  >
                    {isDriveLogoSearching ? 'Mencari...' : 'Cari'}
                  </button>
                </div>
                <div className="flex flex-wrap gap-2 pt-1">
                  {(logoSearchResults.length > 0 ? logoSearchResults : LOGO_PRESETS).map((logo, index) => (
                    <button
                      type="button"
                      key={index}
                      onClick={() => setLogoInput(logo.char)}
                      className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-[11px] rounded border border-slate-800 text-white flex items-center gap-1.5"
                    >
                      <span>{logo.char}</span>
                      <span className="text-[9px] text-gray-500 font-mono">{logo.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-5 py-2 bg-teal-500 text-slate-950 font-bold rounded-lg hover:bg-teal-400 transition"
                >
                  <Save className="w-3.5 h-3.5" /> Amankan Informasi
                </button>
              </div>
            </form>
          </div>

          <div className="space-y-6">
            {/* Form 2: Keamanan Sandi Akun */}
            <div className="bg-slate-900/60 p-5 rounded-2xl border border-slate-850 space-y-4 text-left">
              <h3 className="text-xs font-bold font-mono text-teal-400 uppercase tracking-widest border-b border-slate-800 pb-2 flex items-center gap-1.5">
                <Key className="w-4 h-4 text-teal-400" /> Kredensial Sandi Role Pengguna
              </h3>

              <form onSubmit={handleSaveSecurity} className="space-y-4 text-xs font-sans">
                <div className="space-y-1">
                  <label className="font-semibold text-gray-400">Ganti Password Administrator (Semua Akses):</label>
                  <input
                    type="password"
                    required
                    value={adminPass}
                    onChange={(e) => setAdminPass(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-gray-200 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-gray-400">Ganti Password Coach / Pelatih:</label>
                  <input
                    type="password"
                    required
                    value={userPass}
                    onChange={(e) => setUserPass(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-gray-200 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-gray-400">Ganti Password Wali Murid:</label>
                  <input
                    type="password"
                    required
                    value={waliPass}
                    onChange={(e) => setWaliPass(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-1.5 px-3 text-gray-200 font-mono"
                  />
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 px-5 py-2 bg-teal-500 text-slate-950 font-bold rounded-lg hover:bg-teal-400 transition"
                  >
                    <Save className="w-3.5 h-3.5" /> Ganti Sandi Role
                  </button>
                </div>
              </form>
            </div>

            {/* Form 3: Gaya Estetika & Hak Akses Wali Murid */}
            <div className="bg-slate-900/60 p-5 rounded-2xl border border-slate-850 space-y-4 text-left">
              <h3 className="text-xs font-bold font-mono text-teal-400 uppercase tracking-widest border-b border-slate-800 pb-2 flex items-center gap-1.5">
                <Layout className="w-4 h-4 text-indigo-400" /> Tampilan & Hak Wali Murid
              </h3>

              <form onSubmit={handleSaveStyles} className="space-y-4 text-xs font-sans">
                <div className="space-y-2">
                  <label className="font-semibold text-gray-400 block">Kustomisasi Background Aplikasi:</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setDashboardBg('cyber-field')}
                      className={`py-2 px-3 rounded-lg border text-left transition ${
                        dashboardBg === 'cyber-field' 
                          ? 'border-teal-500 bg-teal-500/10 text-teal-300' 
                          : 'border-slate-800 bg-slate-950 text-gray-400 hover:text-white'
                      }`}
                    >
                      🟢 Lapangan Neon Retro
                    </button>
                    <button
                      type="button"
                      onClick={() => setDashboardBg('sunset-pitch')}
                      className={`py-2 px-3 rounded-lg border text-left transition ${
                        dashboardBg === 'sunset-pitch' 
                          ? 'border-teal-500 bg-teal-500/10 text-teal-300' 
                          : 'border-slate-800 bg-slate-950 text-gray-400 hover:text-white'
                      }`}
                    >
                      🌅 Lapangan Golden Sunset
                    </button>
                    <button
                      type="button"
                      onClick={() => setDashboardBg('neon-grid')}
                      className={`py-2 px-3 rounded-lg border text-left transition ${
                        dashboardBg === 'neon-grid' 
                          ? 'border-indigo-500 bg-indigo-500/10 text-indigo-300' 
                          : 'border-slate-800 bg-slate-950 text-gray-400 hover:text-white'
                      }`}
                    >
                      🌐 Grid Taktikal Sci-Fi
                    </button>
                    <button
                      type="button"
                      onClick={() => setDashboardBg('dark-grass')}
                      className={`py-2 px-3 rounded-lg border text-left transition ${
                        dashboardBg === 'dark-grass' 
                          ? 'border-emerald-500 bg-emerald-500/10 text-emerald-300' 
                          : 'border-slate-800 bg-slate-950 text-gray-400 hover:text-white'
                      }`}
                    >
                      🌿 Rumput Gelap Alami
                    </button>
                  </div>
                </div>

                {/* Buka tutup akses rapot untuk wali murid */}
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-850 space-y-3">
                  <div className="text-[10px] font-bold font-mono text-teal-400 uppercase tracking-widest block">
                    Hak Akses Menu Rapor Wali Murid
                  </div>
                  <p className="text-[11px] text-gray-400 font-mono leading-relaxed">
                    Ubah tombol penyiaran nilai di bawah untuk membuka atau menutup akses modul evaluasi rapor bagi seluruh wali murid.
                  </p>
                  
                  <div className="flex gap-2.5 pt-1">
                    <button
                      type="button"
                      onClick={() => setOpenAssessment(true)}
                      className={`flex-1 py-2 text-xs font-bold uppercase rounded-lg border transition ${
                        openAssessment 
                          ? 'bg-blue-500/15 border-blue-500 text-blue-400 font-extrabold' 
                          : 'bg-slate-900 border-slate-800 text-gray-500 hover:text-white'
                      }`}
                    >
                      🔓 Buka Akses Rapor
                    </button>
                    <button
                      type="button"
                      onClick={() => setOpenAssessment(false)}
                      className={`flex-1 py-2 text-xs font-bold uppercase rounded-lg border transition ${
                        !openAssessment 
                          ? 'bg-rose-500/15 border-rose-500 text-rose-400 font-extrabold' 
                          : 'bg-slate-900 border-slate-800 text-gray-500 hover:text-white'
                      }`}
                    >
                      🔒 Tutup Akses Rapor
                    </button>
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 px-5 py-2 bg-teal-500 text-slate-950 font-bold rounded-lg hover:bg-teal-400 transition"
                  >
                    <Save className="w-3.5 h-3.5" /> Ganti Gaya Visual
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
