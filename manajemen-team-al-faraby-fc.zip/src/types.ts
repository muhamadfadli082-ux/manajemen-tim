/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'admin' | 'user' | 'wali';

export interface Player {
  id: string;
  name: string;
  birthdate: string;
  position: 'Kiper' | 'Bek' | 'Gelandang' | 'Penyerang';
  photo: string; // URL or base64 or path
  className?: string;
  weight?: string;
  height?: string;
  phone?: string;
  statusActive?: boolean;
}

export interface Management {
  teamName: string;
  address: string;
  president: string;
  headCoach: string;
  coach: string;
  manager1: string;
  manager2: string;
  staff1: string;
  staff2: string;
  npsn: string;
  email: string;
  logo: string;
  principal: string;
}

export interface Schedule {
  id: string;
  type: 'Latihan' | 'Sparring' | 'Resmi';
  title: string;
  date: string;
  time: string;
  location: string;
  menu?: string; // Training items
  opponent?: string;
  myScore?: number;
  opponentScore?: number;
  completed?: boolean;
}

export interface Assessment {
  id: string;
  playerId: string;
  playerName: string;
  date: string;
  // Pengetahuan / Knowledge
  knowledge: number; // 0-100
  // Teknik Dasar
  passing: number;
  dribbling: number;
  control: number;
  // Teknik Lanjutan
  shooting: number;
  individualSkill: number;
  vision: number;
  response: number;
  jump: number;
  // Others
  teamwork: number;
  matchMental: number;
  spirit: number;
  endurance: number;
  // Metadata
  notes: string;
  evaluator: string;
}

export interface SyncSettings {
  spreadsheetId: string;
  apiKey: string;
  autoSync: boolean;
  lastSynced: string;
}

export interface AppSettings {
  dashboardBg: 'cyber-field' | 'sunset-pitch' | 'neon-grid' | 'dark-grass';
  openAssessmentToParents: boolean;
}
