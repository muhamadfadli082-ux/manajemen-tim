/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const CODE_GS = `/**
 * MANAJEMEN TEAM AL FARABY FC - Google Apps Script (code.gs)
 * Integrasi Google Spreadsheet, Google Drive, & Google Calendar
 */

// Konstanta Nama Sheet
const SHEET_MANAJEMEN = "Manajemen";
const SHEET_PEMAIN = "Pemain";
const SHEET_JADWAL = "Jadwal";
const SHEET_PENILAIAN = "Penilaian";

/**
 * Melayani Web App HTML
 */
function doGet(e) {
  return HtmlService.createTemplateFromFile('index')
    .evaluate()
    .setTitle('MANAJEMEN TEAM AL FARABY FC')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * Mendapatkan Spreadsheet aktif
 */
function getActiveSpreadsheet() {
  const scriptProperties = PropertiesService.getScriptProperties();
  let ssId = scriptProperties.getProperty('SPREADSHEET_ID');
  
  if (!ssId) {
    // Gunakan spreadsheet tempat script ini tersemat atau buat baru
    try {
      const ssActive = SpreadsheetApp.getActiveSpreadsheet();
      if (ssActive) {
        ssId = ssActive.getId();
        scriptProperties.setProperty('SPREADSHEET_ID', ssId);
        return ssActive;
      }
    } catch(err) {
      // Script berdiri sendiri (Standalone), buat baru
      const newSS = SpreadsheetApp.create("DATA MANAJEMEN TEAM AL FARABY FC");
      ssId = newSS.getId();
      scriptProperties.setProperty('SPREADSHEET_ID', ssId);
      // Panggil setup untuk inisialisasi sheet
      setupInitialSheets(newSS);
      return newSS;
    }
  }
  
  try {
    return SpreadsheetApp.openById(ssId);
  } catch(e) {
    // Jika ID tidak valid, buat spreadsheet baru
    const newSS = SpreadsheetApp.create("DATA MANAJEMEN TEAM AL FARABY FC");
    scriptProperties.setProperty('SPREADSHEET_ID', newSS.getId());
    setupInitialSheets(newSS);
    return newSS;
  }
}

/**
 * Mengubah ID Spreadsheet dalam Script Properties
 */
function updateSpreadsheetId(newId) {
  try {
    const ss = SpreadsheetApp.openById(newId);
    PropertiesService.getScriptProperties().setProperty('SPREADSHEET_ID', newId);
    return { success: true, message: "Berhasil terhubung ke spreadsheet: " + ss.getName() };
  } catch (err) {
    return { success: false, message: "ID Spreadsheet tidak valid atau tidak diizinkan: " + err.message };
  }
}

/**
 * Mendapatkan Data Manajemen
 */
function getManagementData() {
  const ss = getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_MANAJEMEN);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_MANAJEMEN);
    sheet.appendRow(["Kunci", "Nilai"]);
    sheet.appendRow(["teamName", "AL FARABY FC"]);
    sheet.appendRow(["address", "Jl Mayor Damar no 44 Bokor Pagedangan Kec. Turen"]);
    sheet.appendRow(["president", "Krismawan, S.Pd.I"]);
    sheet.appendRow(["headCoach", "Ustadz Ahmad Fauzi, S.Pd."]);
    sheet.appendRow(["coach", "Ustadz Slamet Riyadi, S.Or."]);
    sheet.appendRow(["manager1", "Muhammad Fadli, S.Kom."]);
    sheet.appendRow(["manager2", "Siti Aminah, S.Pd."]);
    sheet.appendRow(["staff1", "Agus Salim"]);
    sheet.appendRow(["staff2", "Dewi Lestari"]);
    sheet.appendRow(["npsn", "20557279"]);
    sheet.appendRow(["email", "sdialfaraby238@gmail.com"]);
    sheet.appendRow(["logo", "⚽"]);
    sheet.appendRow(["principal", "Krismawan, S.Pd.I"]);
    sheet.appendRow(["adminPassword", "admin123"]);
    sheet.appendRow(["userPassword", "coach123"]);
    sheet.appendRow(["waliPassword", "wali123"]);
  }
  
  const values = sheet.getDataRange().getValues();
  const data = {};
  for (let i = 1; i < values.length; i++) {
    const key = values[i][0];
    const val = values[i][1];
    if (key) {
      data[key] = val;
    }
  }
  return data;
}

/**
 * Menyimpan data manajemen
 */
function saveManagementData(data) {
  const ss = getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_MANAJEMEN);
  if (!sheet) return { success: false, message: "Sheet Manajemen tidak ditemukan." };
  
  const values = sheet.getDataRange().getValues();
  const keysInSheet = values.map(row => row[0]);
  
  for (let key in data) {
    const index = keysInSheet.indexOf(key);
    if (index !== -1) {
      // Update cell nilai (kolom B)
      sheet.getRange(index + 1, 2).setValue(data[key]);
    } else {
      // Append baru
      sheet.appendRow([key, data[key]]);
    }
  }
  return { success: true, message: "Data manajemen berhasil disimpan ke Spreadsheet." };
}

/**
 * Get Pemain List
 */
function getPlayers() {
  const ss = getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_PEMAIN);
  if (!sheet) return [];
  
  const values = sheet.getDataRange().getValues();
  if (values.length <= 1) return [];
  
  const players = [];
  const headers = values[0];
  
  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    const player = {};
    headers.forEach((header, index) => {
      player[header] = row[index];
    });
    players.push(player);
  }
  return players;
}

/**
 * Tambah / Edit Pemain
 */
function savePlayer(playerData) {
  const ss = getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_PEMAIN);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_PEMAIN);
    sheet.appendRow(["id", "name", "birthdate", "position", "photo", "className", "weight", "height", "phone", "statusActive"]);
  }
  
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  let rowIndex = -1;
  
  // Cari ID jika update
  if (playerData.id) {
    for (let i = 1; i < values.length; i++) {
      if (values[i][0].toString() === playerData.id.toString()) {
        rowIndex = i + 1;
        break;
      }
    }
  } else {
    // Generate ID Baru
    playerData.id = "PL" + Utilities.formatDate(new Date(), "GMT+7", "yyyyMMdd-HHmmss");
  }
  
  const rowValues = headers.map(header => playerData[header] !== undefined ? playerData[header] : "");
  
  if (rowIndex !== -1) {
    // Update existing row
    sheet.getRange(rowIndex, 1, 1, headers.length).setValues([rowValues]);
    return { success: true, message: "Data pemain berhasil diperbarui.", player: playerData };
  } else {
    // Sembunyikan default statusActive ke true
    if (playerData.statusActive === undefined) {
      playerData.statusActive = true;
      rowValues[headers.indexOf("statusActive")] = true;
    }
    // Append baru
    sheet.appendRow(rowValues);
    return { success: true, message: "Data pemain baru berhasil disimpan.", player: playerData };
  }
}

/**
 * Hapus Pemain
 */
function deletePlayer(id) {
  const ss = getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_PEMAIN);
  if (!sheet) return { success: false, message: "Sheet Pemain tidak ditemukan" };
  
  const values = sheet.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (values[i][0].toString() === id.toString()) {
      sheet.deleteRow(i + 1);
      return { success: true, message: "Pemain berhasil dihapus dari database." };
    }
  }
  return { success: false, message: "ID pemain tidak ditemukan untuk dihapus." };
}

/**
 * Cari Foto di Google Drive berdasarkan nama siswa / kata kunci
 */
function searchPhotosInDrive(keyword) {
  const files = [];
  try {
    const query = "title contains '" + keyword + "' and (mimeType contains 'image/jpeg' or mimeType contains 'image/png')";
    const iterator = DriveApp.searchFiles(query);
    while (iterator.hasNext() && files.length < 10) {
      const file = iterator.next();
      files.push({
        name: file.getName(),
        id: file.getId(),
        url: file.getUrl(),
        thumbnail: file.getThumbnail() || "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=80&q=80"
      });
    }
    return { success: true, files: files };
  } catch (err) {
    return { success: false, message: "Gagal mencari di Google Drive: " + err.message };
  }
}

/**
 * Get Agenda / Jadwal
 */
function getSchedules() {
  const ss = getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_JADWAL);
  if (!sheet) return [];
  
  const values = sheet.getDataRange().getValues();
  if (values.length <= 1) return [];
  
  const schedules = [];
  const headers = values[0];
  
  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    const sched = {};
    headers.forEach((header, index) => {
      sched[header] = row[index];
    });
    schedules.push(sched);
  }
  return schedules;
}

/**
 * Simpan atau Sync Jadwal ke Google Calendar
 */
function saveSchedule(scheduleData) {
  const ss = getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_JADWAL);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_JADWAL);
    sheet.appendRow(["id", "type", "title", "date", "time", "location", "menu", "opponent", "myScore", "opponentScore", "completed"]);
  }
  
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  let rowIndex = -1;
  
  if (scheduleData.id) {
    for (let i = 1; i < values.length; i++) {
      if (values[i][0].toString() === scheduleData.id.toString()) {
        rowIndex = i + 1;
        break;
      }
    }
  } else {
    scheduleData.id = "SCH-" + Utilities.formatDate(new Date(), "GMT+7", "yyyyMMdd-HHmmss");
  }
  
  const rowValues = headers.map(header => scheduleData[header] !== undefined ? scheduleData[header] : "");
  
  if (rowIndex !== -1) {
    sheet.getRange(rowIndex, 1, 1, headers.length).setValues([rowValues]);
  } else {
    sheet.appendRow(rowValues);
  }
  
  // Integrasikan dengan Google Calendar secara otomatis!
  try {
    const cal = CalendarApp.getDefaultCalendar();
    if (cal) {
      const startDateTime = new Date(scheduleData.date + "T" + scheduleData.time + ":00");
      const endDateTime = new Date(startDateTime.getTime() + (2 * 60 * 60 * 1000)); // Durasi 2 jam
      
      const eventTitle = "AL FARABY FC: [" + scheduleData.type + "] - " + scheduleData.title;
      const description = "Menu/Info: " + (scheduleData.menu || "") + "\\nLawan: " + (scheduleData.opponent || "") + "\\nLokasi: " + scheduleData.location;
      
      cal.createEvent(eventTitle, startDateTime, endDateTime, {
        description: description,
        location: scheduleData.location
      });
    }
  } catch(e) {
    // Lewati integrasi kalender jika tidak diotorisasi atau terjadi kesalahan
  }
  
  return { success: true, message: "Agenda baru berhasil disimpan ke Google Sheets & Calendar.", schedule: scheduleData };
}

/**
 * Menyimpan Penilaian Pemain
 */
function saveAssessment(assessmentData) {
  const ss = getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_PENILAIAN);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_PENILAIAN);
    sheet.appendRow([
      "id", "playerId", "playerName", "date", "knowledge", 
      "passing", "dribbling", "control", "shooting", "individualSkill", 
      "vision", "response", "jump", "teamwork", "matchMental", "spirit", "endurance", "notes", "evaluator"
    ]);
  }
  
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  let rowIndex = -1;
  
  if (assessmentData.id) {
    for (let i = 1; i < values.length; i++) {
      if (values[i][0].toString() === assessmentData.id.toString()) {
        rowIndex = i + 1;
        break;
      }
    }
  } else {
    assessmentData.id = "EV-" + Utilities.formatDate(new Date(), "GMT+7", "yyyyMMdd-HHmmss");
  }
  
  const rowValues = headers.map(header => assessmentData[header] !== undefined ? assessmentData[header] : "");
  
  if (rowIndex !== -1) {
    sheet.getRange(rowIndex, 1, 1, headers.length).setValues([rowValues]);
  } else {
    sheet.appendRow(rowValues);
  }
  
  return { success: true, message: "Hasil penilaian " + assessmentData.playerName + " berhasil disimpan ke Spreadsheet.", assessment: assessmentData };
}

/**
 * Get Penilaian List
 */
function getAssessments() {
  const ss = getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_PENILAIAN);
  if (!sheet) return [];
  
  const values = sheet.getDataRange().getValues();
  if (values.length <= 1) return [];
  
  const assessList = [];
  const headers = values[0];
  
  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    const ass = {};
    headers.forEach((header, index) => {
      ass[header] = row[index];
    });
    assessList.push(ass);
  }
  return assessList;
}

/**
 * Bootstrap Awal Sheet Jika Diperlukan
 */
function setupInitialSheets(ss) {
  const ssObj = ss || getActiveSpreadsheet();
  
  // 1. Manajemen setup
  if (!ssObj.getSheetByName(SHEET_MANAJEMEN)) {
    getManagementData(); // Ini otomatis menginisialisasi
  }
  
  // 2. Pemain setup
  if (!ssObj.getSheetByName(SHEET_PEMAIN)) {
    const sh = ssObj.insertSheet(SHEET_PEMAIN);
    sh.appendRow(["id", "name", "birthdate", "position", "photo", "className", "weight", "height", "phone", "statusActive"]);
    sh.appendRow(["PL01", "Ahmad Rafif", "2014-05-12", "Penyerang", "👤", "Siswa Kelas 5A", "38 kg", "142 cm", "081234567801", true]);
  }
  
  // 3. Jadwal setup
  if (!ssObj.getSheetByName(SHEET_JADWAL)) {
    const sh = ssObj.insertSheet(SHEET_JADWAL);
    sh.appendRow(["id", "type", "title", "date", "time", "location", "menu", "opponent", "myScore", "opponentScore", "completed"]);
    sh.appendRow(["S01", "Latihan", "Latihan Fisik & Passing Pendek", "2026-06-10", "15:30", "Lapangan Utama Al Faraby", "Passing drill, cardio", "", "", "", false]);
  }
  
  // 4. Penilaian setup
  if (!ssObj.getSheetByName(SHEET_PENILAIAN)) {
    const sh = ssObj.insertSheet(SHEET_PENILAIAN);
    sh.appendRow([
      "id", "playerId", "playerName", "date", "knowledge", 
      "passing", "dribbling", "control", "shooting", "individualSkill", 
      "vision", "response", "jump", "teamwork", "matchMental", "spirit", "endurance", "notes", "evaluator"
    ]);
  }
}
`;

export const SETUP_GS = `/**
 * MANAJEMEN TEAM AL FARABY FC - Google Apps Script (setup.gs)
 * Jalankan fungsi "installAppletRequirements" ini sekali untuk inisialisasi awal.
 */

function installAppletRequirements() {
  const properties = PropertiesService.getScriptProperties();
  let ssId = properties.getProperty('SPREADSHEET_ID');
  
  let ss;
  if (!ssId) {
    ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) {
      ss = SpreadsheetApp.create("DATA MANAJEMEN TEAM AL FARABY FC");
    }
    properties.setProperty('SPREADSHEET_ID', ss.getId());
  } else {
    try {
      ss = SpreadsheetApp.openById(ssId);
    } catch(e) {
      ss = SpreadsheetApp.getActiveSpreadsheet() || SpreadsheetApp.create("DATA MANAJEMEN TEAM AL FARABY FC");
      properties.setProperty('SPREADSHEET_ID', ss.getId());
    }
  }
  
  Logger.log("Inisialisasi database di spreadsheet: " + ss.getName() + " [ " + ss.getId() + " ]");
  
  // Setup Semua Sheet
  setupInitialSheets(ss);
  
  // Setup Permissions & Integrasi Google Drive
  try {
    const testFolder = DriveApp.getRootFolder();
    Logger.log("Hak akses Google Drive berhasil diverifikasi. Folder root: " + testFolder.getName());
  } catch(e) {
    Logger.log("Peringatan: Gagal memverifikasi akses Drive. Silakan berikan otorisasi saat diminta.");
  }
  
  // Setup Integrasi Google Calendar
  try {
    const defaultCalendar = CalendarApp.getDefaultCalendar();
    Logger.log("Otorisasi Google Calendar OK: " + defaultCalendar.getName());
  } catch(e) {
    Logger.log("Peringatan: Gagal memverifikasi akses Calendar.");
  }
  
  Logger.log("Pemasangan Selesai! Semua lembar pangkalan data Al Faraby FC siap digunakan.");
  return "Instalasi Berhasil! Silakan periksa log eksekusi Apps Script.";
}
`;

export const INDEX_HTML_GAS = `<!DOCTYPE html>
<html>
  <head>
    <base target="_top">
    <meta charset="utf-8">
    <title>MANAJEMEN TEAM AL FARABY FC</title>
    <!-- CSS Tailwind & Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono&display=swap" rel="stylesheet">
    <style>
      body {
        margin: 0;
        padding: 0;
        background-color: #030712;
        color: #f3f4f6;
        font-family: 'Inter', sans-serif;
        text-align: center;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
      }
      .container {
        max-width: 600px;
        padding: 40px;
        background: radial-gradient(100% 100% at 50% 0%, rgba(13, 148, 136, 0.15) 0%, rgba(15, 23, 42, 0) 100%), #0f172a;
        box-shadow: 0 0 40px rgba(13, 148, 136, 0.25);
        border: 1px solid rgba(13, 148, 136, 0.3);
        border-radius: 20px;
      }
      h1 {
        font-family: 'Space Grotesk', sans-serif;
        color: #2dd4bf;
        font-size: 2.2rem;
        margin-bottom: 20px;
        letter-spacing: -0.05em;
        text-shadow: 0 0 10px rgba(45, 212, 191, 0.4);
      }
      p {
        font-size: 1.1rem;
        line-height: 1.6;
        color: #9ca3af;
        margin-bottom: 30px;
      }
      .badge {
        font-family: 'JetBrains Mono', monospace;
        background-color: rgba(13, 148, 136, 0.2);
        color: #2dd4bf;
        padding: 8px 16px;
        border-radius: 100px;
        font-size: 0.85rem;
        border: 1px solid rgba(13, 148, 136, 0.4);
        display: inline-block;
        margin-bottom: 20px;
      }
      .btn {
        background-color: #0d9488;
        color: white;
        text-decoration: none;
        padding: 14px 28px;
        border-radius: 12px;
        font-weight: 600;
        box-shadow: 0 4px 14px rgba(13, 148, 136, 0.4);
        transition: all 0.2s ease;
        display: inline-block;
      }
      .btn:hover {
        background-color: #14b8a6;
        box-shadow: 0 6px 20px rgba(20, 184, 166, 0.6);
        transform: translateY(-2px);
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="badge">SERVER SECURE NODE</div>
      <h1>AL FARABY FC</h1>
      <p>Pangkalan Backend Web Apps Script diaktifkan. Anda dapat memanfaatkan visual antarmuka utama yang disajikan otomatis di host server interaktif utama di AI Studio.</p>
      <a href="<?= ScriptApp.getService().getUrl() ?>" class="btn">Luncurkan Portal Sekolah</a>
    </div>
  </body>
</html>
`;
