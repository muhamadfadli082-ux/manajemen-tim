/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Player, Management, Schedule, Assessment, SyncSettings, AppSettings } from '../types';

export const DEFAULT_PASSWORDS = {
  admin: 'admin123',
  user: 'coach123',
  wali: 'wali123'
};

export const INITIAL_MANAGEMENT: Management = {
  teamName: 'AL FARABY FC',
  address: 'Jl Mayor Damar no 44 Bokor Pagedangan Kec. Turen',
  president: 'Krismawan, S.Pd.I',
  headCoach: 'Ustadz Ahmad Fauzi, S.Pd.',
  coach: 'Ustadz Slamet Riyadi, S.Or.',
  manager1: 'Muhammad Fadli, S.Kom.',
  manager2: 'Siti Aminah, S.Pd.',
  staff1: 'Agus Salim',
  staff2: 'Dewi Lestari',
  npsn: '20557279',
  email: 'sdialfaraby238@gmail.com',
  logo: '⚽', // Emojis or default SVG placeholder
  principal: 'Krismawan, S.Pd.I'
};

export const INITIAL_PLAYERS: Player[] = [
  { id: 'P01', name: 'Ahmad Rafif', birthdate: '2014-05-12', position: 'Penyerang', photo: '👤', className: 'Siswa Kelas 5A', weight: '38 kg', height: '142 cm', phone: '081234567801', statusActive: true },
  { id: 'P02', name: 'Bagas Wibowo', birthdate: '2014-08-22', position: 'Bek', photo: '👤', className: 'Siswa Kelas 5B', weight: '42 kg', height: '146 cm', phone: '081234567802', statusActive: true },
  { id: 'P03', name: 'Choirul Anam', birthdate: '2013-11-03', position: 'Gelandang', photo: '👤', className: 'Siswa Kelas 6A', weight: '45 kg', height: '150 cm', phone: '081234567803', statusActive: true },
  { id: 'P04', name: 'Dani Kurniawan', birthdate: '2014-01-15', position: 'Kiper', photo: '👤', className: 'Siswa Kelas 5A', weight: '40 kg', height: '144 cm', phone: '081234567804', statusActive: true },
  { id: 'P05', name: 'Erlangga Putra', birthdate: '2015-02-18', position: 'Gelandang', photo: '👤', className: 'Siswa Kelas 4B', weight: '35 kg', height: '138 cm', phone: '081234567805', statusActive: true },
  { id: 'P06', name: 'Farez Rahman', birthdate: '2014-09-10', position: 'Bek', photo: '👤', className: 'Siswa Kelas 5B', weight: '39 kg', height: '141 cm', phone: '081234567806', statusActive: true },
  { id: 'P07', name: 'Gavin Mahesa', birthdate: '2013-07-25', position: 'Penyerang', photo: '👤', className: 'Siswa Kelas 6B', weight: '47 kg', height: '153 cm', phone: '081234567807', statusActive: true },
  { id: 'P08', name: 'Hafiz Al-Fatih', birthdate: '2014-12-01', position: 'Bek', photo: '👤', className: 'Siswa Kelas 5A', weight: '41 kg', height: '145 cm', phone: '081234567808', statusActive: true }
];

export const INITIAL_SCHEDULES: Schedule[] = [
  {
    id: 'S01',
    type: 'Latihan',
    title: 'Latihan Fisik & Passing Pendek',
    date: '2026-06-10',
    time: '15:30',
    location: 'Lapangan Utama Al Faraby',
    menu: 'Pemanasan dinamis, Drill passing segitiga, Jogging interval 15 menit, Game internal 7 vs 7.',
    completed: false
  },
  {
    id: 'S02',
    type: 'Sparring',
    title: 'Uji Coba vs SD Harapan Bangsa',
    date: '2026-06-14',
    time: '14:00',
    location: 'Stadion Mini Turen',
    opponent: 'SD Harapan Bangsa',
    myScore: 3,
    opponentScore: 1,
    completed: true
  },
  {
    id: 'S03',
    type: 'Resmi',
    title: 'Piala Danone Cup Malang',
    date: '2026-06-25',
    time: '08:00',
    location: 'Lapangan Kostrad Singosari',
    opponent: 'SDN 1 Wonokerto',
    myScore: 0,
    opponentScore: 0,
    completed: false
  }
];

export const INITIAL_ASSESSMENTS: Assessment[] = [
  {
    id: 'A01',
    playerId: 'P01',
    playerName: 'Ahmad Rafif',
    date: '2026-06-05',
    knowledge: 85,
    passing: 80,
    dribbling: 90,
    control: 85,
    shooting: 92,
    individualSkill: 88,
    vision: 82,
    response: 85,
    jump: 78,
    teamwork: 80,
    matchMental: 90,
    spirit: 95,
    endurance: 84,
    notes: 'Rafif berkembang luar biasa di sektor penyerangan. Finishing dan shooting sangat presisi. Perlu meningkatkan kerjasama tim saat transisi bertahan.',
    evaluator: 'Ustadz Ahmad Fauzi, S.Pd.'
  },
  {
    id: 'A02',
    playerId: 'P02',
    playerName: 'Bagas Wibowo',
    date: '2026-06-05',
    knowledge: 88,
    passing: 82,
    dribbling: 70,
    control: 78,
    shooting: 65,
    individualSkill: 75,
    vision: 85,
    response: 82,
    jump: 88,
    teamwork: 90,
    matchMental: 85,
    spirit: 88,
    endurance: 88,
    notes: 'Bagas bek yang disiplin dan kuat dalam duel udara. Sundulan mantap. Harus melatih akurasi long ball dan kontrol bola pertamanya.',
    evaluator: 'Ustadz Slamet Riyadi, S.Or.'
  }
];

export const INITIAL_SYNC: SyncSettings = {
  spreadsheetId: '1AL-FARABY-FC-SPREADSHEET-ID-EXAMPLE',
  apiKey: 'AlFaraby_Sec_API_998811',
  autoSync: true,
  lastSynced: '2026-06-07 09:30'
};

export const INITIAL_SETTINGS: AppSettings = {
  dashboardBg: 'cyber-field',
  openAssessmentToParents: true
};
